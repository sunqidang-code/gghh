# 🌊 Bitget OnChain Agent SDK + Monitor

> **Agent tooling framework + real-time on-chain monitoring dashboard** for Bitget AI Hackathon Track 2 (Trading Infra).

[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue.svg)](https://www.typescriptlang.org/)
[![Next.js](https://img.shields.io/badge/Next.js-16-black.svg)](https://nextjs.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38bdf8.svg)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 📖 项目简介

**Bitget OnChain Agent SDK + Monitor** 是一个为 Bitget AI Hackathon 赛道二（交易 Infra）打造的双引擎基础设施产品：

1. **Agent 工具框架（SDK 风格）** — 一套清晰的 TypeScript SDK（`@bitget-onchain-agent/sdk`），封装 Bitget Public API、Skill Hub 调用、链上数据查询、市场数据、模拟执行、风险检查等能力，支持 MCP / CLI 风格集成，可通过 npm 安装 + 简单 import 使用。

2. **实时链上监控面板（Web Dashboard）** — 一个深色科技风的实时监控仪表盘，提供多链鲸鱼活动、资金费率、大额转账、Open Interest、Mempool 监控、Agent 信号追踪等可视化能力，并内置 SDK Playground、策略回测评估、Agent 日志 AI 分析器。

### 🎯 赛道二亮点

| 维度 | 实现 |
|------|------|
| **Agent 工具框架** | 完整的 `BitgetOnChainAgent` SDK，包含 5 大 Skill 模块（Market / OnChain / Trading / Risk / SkillHub），12+ 可调用技能，React Hooks 开箱即用 |
| **实时链上监控** | 多链（ETH / SOL / BTC / Base / Arbitrum / BSC）鲸鱼警报、Mempool 实时流、资金费率监控、OI 异动、成交量异常检测 |
| **Agent 信号监控** | 追踪多个 Agent 的决策日志、执行状态、PnL，可视化信号来源（链上 / 技术 / 资金费率 / 情绪 / 订单流） |
| **SDK Playground** | 在浏览器中直接测试 SDK 函数，8 个内置示例，实时输出 + 执行时间统计 |
| **策略评估** | 4 种策略模板（动量 / 均值回归 / 资金费率套利 / 鲸鱼跟随），完整回测指标（Sharpe / Sortino / MaxDD / WinRate / ProfitFactor）+ 链上信号评分 |
| **日志 AI 分析** | 上传 Agent 日志 → 自动提取错误模式、性能瓶颈、优化建议 |
| **MCP / CLI 集成** | SDK 设计兼容 MCP Server 风格，可作为 CLI 工具或 MCP 服务暴露给其他 Agent |

---

## 🏗️ 架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Web Dashboard (Next.js)                   │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ ┌──────┐│
│  │Dashboard │ │Playground│ │Strategy  │ │Logs AI │ │Settings│
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └───┬────┘ └──┬───┘│
└───────┼────────────┼────────────┼────────────┼─────────┼────┘
        │            │            │            │         │
        ▼            ▼            ▼            ▼         ▼
┌─────────────────────────────────────────────────────────────┐
│              @bitget-onchain-agent/sdk (lib/sdk)             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              BitgetOnChainAgent (client.ts)           │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────┐ ┌─────┐│   │
│  │  │ Market  │ │ OnChain │ │ Trading │ │Risk │ │Skill││   │
│  │  │  Skill  │ │  Skill  │ │  Skill  │ │Skill│ │ Hub ││   │
│  │  └────┬────┘ └────┬────┘ └────┬────┘ └─────┘ └─────┘│   │
│  └───────┼───────────┼───────────┼──────────────────────┘   │
│          │           │           │                           │
│          ▼           ▼           ▼                           │
│  ┌──────────────────────────────────────────────────────┐   │
│  │           Bitget REST Client (lib/bitget)             │   │
│  │   Public API · Tickers · Candles · OrderBook · OI     │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 快速开始

### 环境要求

- Node.js 18+ / Bun 1.0+
- npm / pnpm / bun

### 安装

```bash
# 克隆仓库
git clone https://github.com/<your-username>/bitget-onchain-agent.git
cd bitget-onchain-agent

# 安装依赖
bun install
# 或 npm install

# 启动开发服务器
bun run dev
# 或 npm run dev
```

访问 `http://localhost:3000` 即可看到监控面板。

### 配置（可选）

面板在 **无 API Key** 时也能完整运行（使用内置模拟数据层）。如需接入真实 Bitget 数据：

1. 在面板的 **Settings** 页面填入 Bitget API Key / Secret / Passphrase
2. （可选）填入 Playbook Key 以启用 Skill Hub 认证调用
3. 配置保存在浏览器 localStorage，不会上传到任何服务器

或通过环境变量配置（服务端）：

```bash
# .env.local
BITGET_API_KEY=your_api_key
BITGET_API_SECRET=your_api_secret
BITGET_PASSPHRASE=your_passphrase
BITGET_PLAYBOOK_KEY=your_playbook_key
```

---

## 📦 SDK 使用

### 基础用法

```typescript
import { createAgent } from '@/lib/sdk';

const agent = createAgent({
  apiKey: process.env.BITGET_API_KEY,
  playbookKey: process.env.BITGET_PLAYBOOK_KEY,
});

// 1. 市场数据
const ticker = await agent.market.getTicker('BTCUSDT');
const candles = await agent.market.getCandles('ETHUSDT', '1h', 200);
const rsi = await agent.market.getRSI('SOLUSDT', 14, '4h');

// 2. 链上数据
const whales = await agent.onchain.getWhaleAlerts({
  chain: 'ethereum',
  minUsd: 500_000,
  limit: 20,
});
const mempool = await agent.onchain.getMempool('solana', 15);

// 3. 模拟执行
const sim = await agent.trading.simulateOrder({
  symbol: 'BTCUSDT',
  side: 'buy',
  sizeUsd: 50_000,
});
console.log(`Slippage: ${sim.slippageBps} bps`);

// 4. 风险检查
const risk = await agent.risk.checkPosition({
  symbol: 'BTCUSDT',
  sizeUsd: 10_000,
  leverage: 5,
  accountEquityUsd: 50_000,
});
console.log(`Risk score: ${risk.score}/100, passed: ${risk.passed}`);

// 5. Skill Hub
const skills = await agent.listSkills();
```

### React Hooks

```tsx
import {
  useTickers,
  useWhaleAlerts,
  useAlerts,
  useAgentSignals,
  useMempool,
} from '@/lib/sdk/hooks';

function Dashboard() {
  const { data: tickers, loading } = useTickers(['BTCUSDT', 'ETHUSDT'], 3000);
  const { data: whales } = useWhaleAlerts(20, 5000);
  const { data: alerts } = useAlerts(4000);
  const { data: signals } = useAgentSignals(6000);
  const { data: mempool } = useMempool('ethereum', 3000);

  if (loading) return <div>Loading...</div>;
  return <div>{/* ... */}</div>;
}
```

### MCP / CLI 集成

SDK 设计兼容 MCP（Model Context Protocol）Server 风格。每个 Skill 都是一个可独立调用的工具：

```typescript
import { BitgetOnChainAgent } from '@/lib/sdk';

const agent = new BitgetOnChainAgent({});

// 作为 MCP 工具暴露
const mcpTools = [
  {
    name: 'get_ticker',
    description: 'Get latest ticker for a Bitget symbol',
    inputSchema: { symbol: 'string' },
    handler: (input: { symbol: string }) => agent.market.getTicker(input.symbol),
  },
  {
    name: 'get_whale_alerts',
    description: 'Get recent whale transfer alerts',
    inputSchema: { chain: 'string', minUsd: 'number' },
    handler: (input: { chain: any; minUsd: number }) =>
      agent.onchain.getWhaleAlerts({ chain: input.chain, minUsd: input.minUsd }),
  },
  {
    name: 'check_risk',
    description: 'Run pre-trade risk checks',
    inputSchema: { symbol: 'string', sizeUsd: 'number', leverage: 'number' },
    handler: (input: any) => agent.risk.checkPosition(input),
  },
  // ... 更多工具
];
```

---

## 🎛️ 面板功能

### 1. 仪表盘首页（Dashboard）

- **顶部 Ticker Tape** — 10 个主流币种滚动行情
- **统计卡片** — 24h 成交量、鲸鱼流水、活跃警报、Agent 数量、平均置信度
- **市场概览** — 8 个币种实时价格 + 24h 涨跌 + 成交量
- **市场热力图** — 按涨跌幅着色的网格视图，集成资金费率 + OI 侧边栏
- **实时警报流** — 鲸鱼异动、资金费率极端值、OI 异动、成交量异常、Agent 信号
- **鲸鱼活动** — 多链大额转账实时流，标注交易所流入/流出
- **Agent 信号** — 多 Agent 决策追踪，可视化信号来源 + 置信度
- **Mempool 监控** — ETH 链上 pending 交易实时流

### 2. SDK Playground

- 8 个内置示例（Ticker / Candles / OrderBook / Whale / Mempool / Simulate / Risk / Skills）
- 代码编辑器 + 一键运行
- 实时输出 + 执行时间 + 状态指示
- 复制代码 / 重置功能

### 3. 策略评估（Strategy Eval）

- 4 种策略模板：动量、均值回归、资金费率套利、鲸鱼跟随
- 可配置：交易对、周期、回测天数、初始资金、仓位比例、止损/止盈、杠杆
- 完整回测指标：总收益、年化、Sharpe、Sortino、最大回撤、胜率、盈亏比、暴露度
- 权益曲线可视化
- 链上信号评分（0-100）
- 最近交易明细表

### 4. 日志分析器（Log Analyzer）

- 上传 Agent 日志文件（或加载示例）
- AI 自动分析：
  - **摘要** — 日志总体情况描述
  - **问题检测** — 关键错误、警告、性能瓶颈
  - **优化建议** — 带影响等级的可执行建议
  - **模式识别** — 高频错误模式提取
  - **指标统计** — 条目数、错误率、Agent 数、平均延迟、成功率

### 5. 设置（Settings）

- Bitget API Key / Secret / Passphrase 配置
- Playbook Key（Skill Hub 认证）
- 默认产品类型（SPOT / USDT-FUTURES / COIN-FUTURES）
- 默认杠杆 + 最大暴露度
- 警报阈值配置（鲸鱼最小金额、资金费率上限、OI 变化阈值、成交量倍数）
- 遥测开关
- 连接测试 + 重置

---

## 🛠️ 技术栈

| 层 | 技术 |
|----|------|
| **框架** | Next.js 16 (App Router) + TypeScript 5 |
| **样式** | Tailwind CSS 4 + shadcn/ui + 玻璃拟态 |
| **状态** | Zustand (persist) |
| **图标** | lucide-react |
| **通知** | sonner |
| **SDK** | 纯 TypeScript，零运行时依赖，兼容 Node / Bun / Edge / Browser |
| **数据源** | Bitget Public API v2 + 内置模拟数据层（无 Key 也能运行） |

---

## 📁 项目结构

```
bitget-onchain-agent/
├── src/
│   ├── app/                      # Next.js App Router
│   │   ├── layout.tsx            # 根布局（深色主题）
│   │   ├── page.tsx              # 主页面（侧边栏 + 多视图）
│   │   └── globals.css           # 全局样式 + 玻璃拟态工具类
│   ├── lib/
│   │   ├── sdk/                  # @bitget-onchain-agent/sdk
│   │   │   ├── index.ts          # 统一导出
│   │   │   ├── client.ts         # BitgetOnChainAgent 主类
│   │   │   ├── types.ts          # 所有 TypeScript 类型
│   │   │   ├── skills/           # Skill 模块
│   │   │   │   ├── market-data.ts
│   │   │   │   ├── onchain.ts
│   │   │   │   ├── trading.ts
│   │   │   │   ├── risk.ts
│   │   │   │   └── skill-hub.ts
│   │   │   └── hooks/            # React Hooks
│   │   │       └── index.ts
│   │   ├── bitget/               # Bitget API 客户端
│   │   │   └── rest.ts
│   │   └── mock/                 # 模拟数据层
│   │       ├── data.ts
│   │       └── backtest.ts
│   ├── components/
│   │   ├── dashboard/            # 仪表盘组件
│   │   ├── playground/           # SDK Playground
│   │   ├── strategy/             # 策略评估
│   │   ├── logs/                 # 日志分析
│   │   ├── settings/             # 设置
│   │   ├── shared/               # 共享组件
│   │   └── ui/                   # shadcn/ui 基础组件
│   └── store/
│       └── app-store.ts          # Zustand 全局状态
├── public/
│   └── logo.svg
├── package.json
├── tsconfig.json
├── next.config.ts
└── README.md
```

---

## 🌐 部署到 Netlify

### 方法一：通过 Git 连接（推荐）

1. 将代码推送到 GitHub 仓库
2. 登录 [Netlify](https://app.netlify.com/)
3. 点击 **Add new site** → **Import an existing project**
4. 选择你的 GitHub 仓库
5. 配置构建设置：
   - **Build command**: `bun run build` 或 `npm run build`
   - **Publish directory**: `.next`
   - **Node version**: 18 或更高
6. 点击 **Deploy**

### 方法二：通过 Netlify CLI

```bash
# 安装 Netlify CLI
npm install -g netlify-cli

# 登录
netlify login

# 初始化站点
netlify init

# 构建并部署
netlify deploy --build --prod
```

### 环境变量（可选）

在 Netlify 的 Site settings → Environment variables 中添加：

```
BITGET_API_KEY=your_key         # 可选，不填则使用模拟数据
BITGET_API_SECRET=your_secret   # 可选
BITGET_PASSPHRASE=your_pass     # 可选
BITGET_PLAYBOOK_KEY=your_key    # 可选
```

### netlify.toml 配置

项目根目录已包含 `netlify.toml`，配置如下：

```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

---

## 🔌 Bitget 工具使用说明

本项目使用了以下 Bitget 工具 / API：

| 工具 | 用途 | 状态 |
|------|------|------|
| **Bitget Public API v2** | 行情数据（Ticker / Candles / OrderBook / Funding Rate / OI） | ✅ 已集成 |
| **Skill Hub** | 链上 Skill 调用框架（SDK 设计兼容） | ✅ 适配器已实现 |
| **Playbook Key** | Skill Hub 认证 | ✅ 配置支持 |
| **MCP Server** | SDK 工具暴露给外部 Agent | ✅ 设计兼容 |
| **Agent Hub** | Agent 工具框架参考 | ✅ 架构参考 |

> **注**：面板在无 API Key 时使用内置模拟数据层完整运行，便于评委直接体验所有功能。配置真实 API Key 后，SDK 会自动切换到 Bitget 实时数据。

---

## 🧪 开发

```bash
# 开发服务器
bun run dev

# 类型检查
npx tsc --noEmit

# Lint
bun run lint

# 构建
bun run build
```

---

## 📄 License

MIT License — 详见 [LICENSE](LICENSE)

---

## 🙏 致谢

- [Bitget AI Hackathon](https://www.bitget.com/) — 赛事主办方
- [Bitget Agent Hub](https://github.com/Bitget-AI/agent_hub) — SDK 架构参考
- [shadcn/ui](https://ui.shadcn.com/) — UI 组件库
- [Tailwind CSS](https://tailwindcss.com/) — 样式框架
- [lucide-react](https://lucide.dev/) — 图标库

---

<p align="center">
  Built for Bitget AI Hackathon · Track 2 (Trading Infra)
</p>
