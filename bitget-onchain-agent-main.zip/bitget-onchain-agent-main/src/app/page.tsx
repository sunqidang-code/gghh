"use client";

import { useState } from "react";
import { DashboardView } from "@/components/dashboard/dashboard-view";
import { PlaygroundView } from "@/components/playground/playground-view";
import { StrategyView } from "@/components/strategy/strategy-view";
import { LogsView } from "@/components/logs/logs-view";
import { SettingsView } from "@/components/settings/settings-view";
import { useAppStore } from "@/store/app-store";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Terminal,
  TrendingUp,
  FileSearch,
  Settings,
  Github,
  Menu,
  X,
  Activity,
  Zap,
} from "lucide-react";

const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, description: "Real-time market & on-chain monitoring" },
  { id: "playground", label: "SDK Playground", icon: Terminal, description: "Test SDK functions in-browser" },
  { id: "strategy", label: "Strategy Eval", icon: TrendingUp, description: "Backtest + signal scoring" },
  { id: "logs", label: "Log Analyzer", icon: FileSearch, description: "AI-powered agent log analysis" },
  { id: "settings", label: "Settings", icon: Settings, description: "API keys & alert thresholds" },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const { settings } = useAppStore();

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-background/80 backdrop-blur-xl">
        <div className="flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="lg:hidden text-muted-foreground hover:text-foreground"
            >
              {mobileNavOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="relative h-7 w-7 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center">
                <Zap className="h-4 w-4 text-white" fill="white" />
              </div>
              <div className="hidden sm:block">
                <div className="text-sm font-bold leading-tight">Bitget OnChain Agent</div>
                <div className="text-[9px] text-muted-foreground leading-tight">
                  SDK + Monitor · Track 2 Trading Infra
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-1.5 rounded-full border border-emerald-500/20 bg-emerald-500/5 px-2.5 py-1">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
              </span>
              <span className="text-[10px] font-medium text-emerald-300">Live</span>
            </div>
            <a
              href="https://github.com/Bitget-AI/agent_hub"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 rounded-md border border-white/10 px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground hover:bg-accent/30 transition-colors"
            >
              <Github className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Agent Hub</span>
            </a>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={cn(
            "fixed lg:sticky top-14 z-30 h-[calc(100vh-3.5rem)] w-60 shrink-0 border-r border-white/5 bg-background/95 backdrop-blur-xl transition-transform",
            mobileNavOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
          )}
        >
          <nav className="flex flex-col gap-1 p-3">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileNavOpen(false);
                  }}
                  className={cn(
                    "group flex items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-colors",
                    isActive
                      ? "bg-gradient-to-r from-cyan-500/10 to-violet-500/10 border border-cyan-500/20"
                      : "hover:bg-accent/30 border border-transparent",
                  )}
                >
                  <Icon
                    className={cn(
                      "h-4 w-4 mt-0.5 shrink-0",
                      isActive ? "text-cyan-400" : "text-muted-foreground group-hover:text-foreground",
                    )}
                  />
                  <div className="min-w-0">
                    <div
                      className={cn(
                        "text-xs font-semibold",
                        isActive ? "text-foreground" : "text-muted-foreground group-hover:text-foreground",
                      )}
                    >
                      {item.label}
                    </div>
                    <div className="text-[10px] text-muted-foreground/70 line-clamp-1">
                      {item.description}
                    </div>
                  </div>
                </button>
              );
            })}
          </nav>

          {/* Status footer */}
          <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-white/5">
            <div className="rounded-md border border-white/5 bg-white/[0.02] p-2.5">
              <div className="flex items-center gap-1.5 mb-1.5">
                <Activity className="h-3 w-3 text-cyan-400" />
                <span className="text-[10px] font-semibold">System Status</span>
              </div>
              <div className="space-y-1 text-[9px]">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Bitget API</span>
                  <span className="flex items-center gap-1 text-emerald-400">
                    <span className="h-1 w-1 rounded-full bg-emerald-400" />
                    Online
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Auth</span>
                  <span className={settings.apiKey ? "text-emerald-400" : "text-amber-400"}>
                    {settings.apiKey ? "Configured" : "Public"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Skill Hub</span>
                  <span className={settings.playbookKey ? "text-emerald-400" : "text-amber-400"}>
                    {settings.playbookKey ? "Connected" : "Demo"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Mobile overlay */}
        {mobileNavOpen && (
          <div
            className="fixed inset-0 top-14 z-20 bg-black/50 lg:hidden"
            onClick={() => setMobileNavOpen(false)}
          />
        )}

        {/* Main content */}
        <main className="flex-1 min-w-0 p-4 lg:p-6">
          <div className="mx-auto max-w-[1600px]">
            {activeTab === "dashboard" && <DashboardView />}
            {activeTab === "playground" && <PlaygroundView />}
            {activeTab === "strategy" && <StrategyView />}
            {activeTab === "logs" && <LogsView />}
            {activeTab === "settings" && <SettingsView />}
          </div>
        </main>
      </div>
    </div>
  );
}
