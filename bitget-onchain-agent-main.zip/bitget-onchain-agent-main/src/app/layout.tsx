import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Bitget OnChain Agent SDK + Monitor — Trading Infra for AI Agents",
  description:
    "A production-grade Agent tooling framework + real-time on-chain monitoring dashboard for Bitget AI Hackathon Track 2 (Trading Infra). SDK-style TypeScript library, multi-chain whale tracking, funding-rate alerts, mempool monitoring, and an in-browser SDK playground.",
  keywords: [
    "Bitget",
    "OnChain",
    "Agent SDK",
    "Trading Infrastructure",
    "AI Trading",
    "Skill Hub",
    "MCP",
    "Whale Monitoring",
    "Funding Rate",
    "Bitget AI Hackathon",
  ],
  authors: [{ name: "Bitget OnChain Agent Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Bitget OnChain Agent SDK + Monitor",
    description:
      "Agent tooling framework + real-time on-chain monitoring dashboard for Bitget AI Hackathon Track 2.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Bitget OnChain Agent SDK + Monitor",
    description:
      "Agent tooling framework + real-time on-chain monitoring dashboard for Bitget AI Hackathon Track 2.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Toaster />
        <SonnerToaster richColors position="top-right" />
      </body>
    </html>
  );
}
