"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useBacktest } from "@/lib/sdk/hooks";
import { toast } from "sonner";
import { Play, TrendingUp, Activity, Target, AlertTriangle, Gauge, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import type { BacktestResult } from "@/lib/sdk/types";

const STRATEGIES = [
  {
    id: "momentum",
    name: "Momentum",
    description: "Buy on positive funding + rising OI, exit on RSI > 70",
    icon: TrendingUp,
    color: "text-emerald-400",
  },
  {
    id: "mean_reversion",
    name: "Mean Reversion",
    description: "Fade extreme funding rates, exit on return to mean",
    icon: Activity,
    color: "text-cyan-400",
  },
  {
    id: "funding_arb",
    name: "Funding Arb",
    description: "Long spot / short perp when funding > 0.05%",
    icon: Target,
    color: "text-violet-400",
  },
  {
    id: "whale_follow",
    name: "Whale Follow",
    description: "Enter on whale exchange outflow signal",
    icon: AlertTriangle,
    color: "text-amber-400",
  },
];

export function StrategyView() {
  const [strategy, setStrategy] = useState("momentum");
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [days, setDays] = useState(30);
  const [capital, setCapital] = useState(10000);
  const [positionSize, setPositionSize] = useState(20);
  const [stopLoss, setStopLoss] = useState(3);
  const [takeProfit, setTakeProfit] = useState(6);
  const [leverage, setLeverage] = useState(5);

  const { result, loading, run } = useBacktest();

  const handleRun = async () => {
    await run({
      symbol,
      strategy: strategy as "momentum" | "mean_reversion" | "funding_arb" | "whale_follow",
      interval: "1h",
      days,
      initialCapital: capital,
      positionSizePct: positionSize / 100,
      stopLossPct: stopLoss / 100,
      takeProfitPct: takeProfit / 100,
      maxLeverage: leverage,
    });
    toast.success("Backtest completed", {
      description: `${days} days · ${symbol} · ${strategy}`,
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Config panel */}
      <Card className="glass p-4 lg:col-span-4 space-y-4">
        <div className="flex items-center gap-2">
          <Gauge className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold">Strategy Config</h3>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Strategy</Label>
          <div className="grid grid-cols-2 gap-2">
            {STRATEGIES.map((s) => {
              const Icon = s.icon;
              return (
                <button
                  key={s.id}
                  onClick={() => setStrategy(s.id)}
                  className={cn(
                    "rounded-md border p-2 text-left transition-colors",
                    strategy === s.id
                      ? "border-cyan-500/30 bg-cyan-500/10"
                      : "border-white/5 hover:bg-accent/30",
                  )}
                >
                  <Icon className={cn("h-3.5 w-3.5 mb-1", s.color)} />
                  <div className="text-[11px] font-semibold">{s.name}</div>
                  <div className="text-[9px] text-muted-foreground line-clamp-2 mt-0.5">
                    {s.description}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label className="text-xs">Symbol</Label>
            <Input
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              className="h-8 text-xs font-mono"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Days</Label>
            <Input
              type="number"
              value={days}
              onChange={(e) => setDays(Number(e.target.value))}
              className="h-8 text-xs"
              min={7}
              max={365}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label className="text-xs">Capital (USD)</Label>
            <Input
              type="number"
              value={capital}
              onChange={(e) => setCapital(Number(e.target.value))}
              className="h-8 text-xs"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Position Size %</Label>
            <Input
              type="number"
              value={positionSize}
              onChange={(e) => setPositionSize(Number(e.target.value))}
              className="h-8 text-xs"
              min={1}
              max={100}
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="space-y-1">
            <Label className="text-xs">SL %</Label>
            <Input
              type="number"
              value={stopLoss}
              onChange={(e) => setStopLoss(Number(e.target.value))}
              className="h-8 text-xs"
              step={0.5}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">TP %</Label>
            <Input
              type="number"
              value={takeProfit}
              onChange={(e) => setTakeProfit(Number(e.target.value))}
              className="h-8 text-xs"
              step={0.5}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Lev</Label>
            <Input
              type="number"
              value={leverage}
              onChange={(e) => setLeverage(Number(e.target.value))}
              className="h-8 text-xs"
              min={1}
              max={50}
            />
          </div>
        </div>

        <Button
          onClick={handleRun}
          disabled={loading}
          className="w-full bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30"
        >
          {loading ? (
            <>
              <div className="h-3 w-3 mr-2 rounded-full border-2 border-cyan-300/30 border-t-cyan-300 animate-spin" />
              Running backtest...
            </>
          ) : (
            <>
              <Play className="h-3.5 w-3.5 mr-2" />
              Run Backtest
            </>
          )}
        </Button>
      </Card>

      {/* Results panel */}
      <div className="lg:col-span-8">
        {result ? (
          <BacktestResults result={result} />
        ) : (
          <Card className="glass p-8 text-center h-full flex flex-col items-center justify-center">
            <Trophy className="h-10 w-10 text-muted-foreground/30 mb-3" />
            <p className="text-sm text-muted-foreground">
              Configure your strategy and run a backtest to see results
            </p>
            <p className="text-[10px] text-muted-foreground/60 mt-1">
              Equity curve, trade log, risk metrics, and on-chain signal score
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}

function BacktestResults({ result }: { result: BacktestResult }) {
  const m = result.metrics;
  const isProfitable = m.totalReturnPct >= 0;

  const metricCards = [
    { label: "Total Return", value: `${m.totalReturnPct >= 0 ? "+" : ""}${m.totalReturnPct}%`, icon: TrendingUp, color: isProfitable ? "text-emerald-400" : "text-rose-400" },
    { label: "Sharpe", value: m.sharpeRatio.toFixed(2), icon: Activity, color: m.sharpeRatio > 1 ? "text-emerald-400" : "text-amber-400" },
    { label: "Max DD", value: `${m.maxDrawdownPct}%`, icon: AlertTriangle, color: "text-rose-400" },
    { label: "Win Rate", value: `${m.winRate}%`, icon: Target, color: m.winRate > 50 ? "text-emerald-400" : "text-amber-400" },
    { label: "Profit Factor", value: m.profitFactor.toFixed(2), icon: Gauge, color: m.profitFactor > 1 ? "text-emerald-400" : "text-rose-400" },
    { label: "Trades", value: String(m.totalTrades), icon: Activity, color: "text-cyan-400" },
  ];

  return (
    <div className="space-y-4">
      {/* Signal score banner */}
      <Card className="glass p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-14 w-14">
              <svg className="h-14 w-14 -rotate-90" viewBox="0 0 56 56">
                <circle cx="28" cy="28" r="24" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="4" />
                <circle
                  cx="28"
                  cy="28"
                  r="24"
                  fill="none"
                  stroke={result.signalScore > 70 ? "#10b981" : result.signalScore > 40 ? "#f59e0b" : "#f43f5e"}
                  strokeWidth="4"
                  strokeDasharray={`${(result.signalScore / 100) * 150.8} 150.8`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-sm font-bold">{result.signalScore}</span>
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Composite Signal Score</div>
              <div className="text-sm font-semibold">
                {result.signalScore > 70 ? "Strong Buy Signal" : result.signalScore > 50 ? "Moderate Signal" : result.signalScore > 30 ? "Weak Signal" : "Avoid"}
              </div>
              <div className="text-[10px] text-muted-foreground">
                Blend of on-chain + technical + funding signals
              </div>
            </div>
          </div>
          <Badge
            variant="outline"
            className={cn(
              "text-xs",
              result.signalScore > 70
                ? "border-emerald-500/30 text-emerald-300"
                : result.signalScore > 40
                  ? "border-amber-500/30 text-amber-300"
                  : "border-rose-500/30 text-rose-300",
            )}
          >
            {result.config.symbol} · {result.config.interval}
          </Badge>
        </div>
      </Card>

      {/* Metric cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
        {metricCards.map((mc) => {
          const Icon = mc.icon;
          return (
            <Card key={mc.label} className="glass p-3">
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <Icon className="h-3 w-3" />
                {mc.label}
              </div>
              <div className={cn("mt-1 text-lg font-bold tabular-nums", mc.color)}>
                {mc.value}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Equity curve */}
      <Card className="glass p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-semibold">Equity Curve</h4>
          <span className="text-[10px] text-muted-foreground">
            {result.config.startTime && result.config.endTime
              ? `${new Date(result.config.startTime).toLocaleDateString()} → ${new Date(result.config.endTime).toLocaleDateString()}`
              : ""}
          </span>
        </div>
        <EquityChart data={result.equityCurve} />
      </Card>

      {/* Trade log */}
      <Tabs defaultValue="trades">
        <TabsList className="bg-white/5">
          <TabsTrigger value="trades" className="text-xs">Trade Log ({result.trades.length})</TabsTrigger>
          <TabsTrigger value="metrics" className="text-xs">Full Metrics</TabsTrigger>
        </TabsList>
        <TabsContent value="trades">
          <Card className="glass p-0 overflow-hidden">
            <div className="max-h-[300px] overflow-y-auto scrollbar-thin">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-card/95 backdrop-blur">
                  <tr className="text-left text-[10px] uppercase text-muted-foreground">
                    <th className="p-2">#</th>
                    <th className="p-2">Side</th>
                    <th className="p-2">Entry</th>
                    <th className="p-2">Exit</th>
                    <th className="p-2 text-right">PnL</th>
                    <th className="p-2 text-right">Return</th>
                    <th className="p-2 text-right">Hold</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {result.trades.slice(0, 50).map((t, i) => (
                    <tr key={t.id} className="hover:bg-accent/20">
                      <td className="p-2 text-muted-foreground">{i + 1}</td>
                      <td className="p-2">
                        <span className={cn("font-semibold", t.side === "long" ? "text-emerald-400" : "text-rose-400")}>
                          {t.side.toUpperCase()}
                        </span>
                      </td>
                      <td className="p-2 tabular-nums">{t.entryPrice.toFixed(2)}</td>
                      <td className="p-2 tabular-nums">{t.exitPrice.toFixed(2)}</td>
                      <td className={cn("p-2 text-right tabular-nums font-medium", t.pnlUsd >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {t.pnlUsd >= 0 ? "+" : ""}${t.pnlUsd.toFixed(2)}
                      </td>
                      <td className={cn("p-2 text-right tabular-nums", t.returnPct >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {t.returnPct >= 0 ? "+" : ""}{t.returnPct.toFixed(2)}%
                      </td>
                      <td className="p-2 text-right text-muted-foreground tabular-nums">
                        {((t.exitTs - t.entryTs) / 3_600_000).toFixed(1)}h
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>
        <TabsContent value="metrics">
          <Card className="glass p-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
              <MetricRow label="Annualized Return" value={`${m.annualizedReturnPct}%`} />
              <MetricRow label="Sortino Ratio" value={m.sortinoRatio.toFixed(2)} />
              <MetricRow label="Avg Win" value={`$${m.avgWinUsd}`} />
              <MetricRow label="Avg Loss" value={`$${m.avgLossUsd}`} />
              <MetricRow label="Exposure" value={`${m.exposurePct}%`} />
              <MetricRow label="Fee Rate" value={`${(result.config.feeRate * 100).toFixed(3)}%`} />
              <MetricRow label="Slippage" value={`${result.config.slippageBps} bps`} />
              <MetricRow label="Initial Capital" value={`$${result.config.initialCapital.toLocaleString()}`} />
              <MetricRow label="Max Leverage" value={`${result.config.maxLeverage}x`} />
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MetricRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-semibold tabular-nums">{value}</span>
    </div>
  );
}

function EquityChart({ data }: { data: { ts: number; equity: number; drawdown: number }[] }) {
  if (!data.length) return null;
  const equities = data.map((d) => d.equity);
  const min = Math.min(...equities);
  const max = Math.max(...equities);
  const range = max - min || 1;
  const width = 100;
  const height = 40;

  const points = data
    .map((d, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - ((d.equity - min) / range) * height;
      return `${x},${y}`;
    })
    .join(" ");

  const isUp = data[data.length - 1].equity >= data[0].equity;
  const color = isUp ? "#10b981" : "#f43f5e";

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-32" preserveAspectRatio="none">
        <defs>
          <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <polygon points={`0,${height} ${points} ${width},${height}`} fill="url(#equityGrad)" />
        <polyline points={points} fill="none" stroke={color} strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
        <span>${min.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
        <span className={isUp ? "text-emerald-400" : "text-rose-400"}>
          Final: ${data[data.length - 1].equity.toLocaleString(undefined, { maximumFractionDigits: 0 })}
        </span>
        <span>${max.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
      </div>
    </div>
  );
}
