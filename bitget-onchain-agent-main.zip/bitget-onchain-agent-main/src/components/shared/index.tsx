"use client";

import { cn } from "@/lib/utils";
import { ArrowDown, ArrowUp } from "lucide-react";

interface PriceChangeProps {
  value: number;
  className?: string;
  showIcon?: boolean;
  suffix?: string;
}

export function PriceChange({ value, className, showIcon = true, suffix = "%" }: PriceChangeProps) {
  const isUp = value >= 0;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 tabular-nums font-medium",
        isUp ? "text-emerald-400" : "text-rose-400",
        className,
      )}
    >
      {showIcon && (isUp ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
      {isUp ? "+" : ""}
      {value.toFixed(2)}
      {suffix}
    </span>
  );
}

interface SeverityBadgeProps {
  severity: "info" | "warning" | "critical";
  className?: string;
}

export function SeverityBadge({ severity, className }: SeverityBadgeProps) {
  const styles = {
    info: "bg-sky-500/10 text-sky-300 border-sky-500/20",
    warning: "bg-amber-500/10 text-amber-300 border-amber-500/20",
    critical: "bg-rose-500/10 text-rose-300 border-rose-500/20",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider",
        styles[severity],
        className,
      )}
    >
      {severity}
    </span>
  );
}

interface LiveDotProps {
  className?: string;
}

export function LiveDot({ className }: LiveDotProps) {
  return (
    <span className={cn("relative inline-flex h-2 w-2", className)}>
      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
      <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
    </span>
  );
}

interface ChainIconProps {
  chain: string;
  className?: string;
}

const CHAIN_COLORS: Record<string, string> = {
  ethereum: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
  solana: "bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/30",
  bitcoin: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  base: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  arbitrum: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  bsc: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
};

export function ChainIcon({ chain, className }: ChainIconProps) {
  const symbol = chain === "ethereum" ? "ETH" : chain === "solana" ? "SOL" : chain === "bitcoin" ? "BTC" : chain.slice(0, 3).toUpperCase();
  return (
    <span
      className={cn(
        "inline-flex h-6 w-6 items-center justify-center rounded-full border text-[9px] font-bold",
        CHAIN_COLORS[chain] ?? "bg-zinc-500/20 text-zinc-300 border-zinc-500/30",
        className,
      )}
    >
      {symbol}
    </span>
  );
}

export function formatUsd(value: number, compact = true): string {
  if (compact) {
    if (Math.abs(value) >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
    if (Math.abs(value) >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
    if (Math.abs(value) >= 1e3) return `$${(value / 1e3).toFixed(2)}K`;
  }
  return `$${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

export function formatNumber(value: number, decimals = 2): string {
  return value.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  return `${day}d ago`;
}
