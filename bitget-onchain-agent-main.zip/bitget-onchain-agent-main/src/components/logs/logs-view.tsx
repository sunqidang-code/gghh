"use client";

import { useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Upload, FileText, Sparkles, AlertTriangle, CheckCircle2, Lightbulb, TrendingUp, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface LogEntry {
  ts: string;
  level: "INFO" | "WARN" | "ERROR" | "DEBUG";
  agent: string;
  message: string;
}

interface AnalysisResult {
  summary: string;
  issues: { severity: "critical" | "warning" | "info"; title: string; detail: string }[];
  recommendations: { title: string; detail: string; impact: "high" | "medium" | "low" }[];
  metrics: {
    totalEntries: number;
    errorCount: number;
    warningCount: number;
    agentsAffected: number;
    avgLatencyMs: number;
    successRate: number;
  };
  patterns: { pattern: string; frequency: number; example: string }[];
}

const SAMPLE_LOG = `2025-06-17T08:23:14.021Z INFO  [momentum-bot-1] Signal generated: BTCUSDT LONG confidence=0.78
2025-06-17T08:23:14.156Z INFO  [momentum-bot-1] Order placed: BTCUSDT LONG size=0.5 entry=67245.5
2025-06-17T08:23:14.892Z WARN  [momentum-bot-1] Slippage exceeded threshold: 12bps > 8bps max
2025-06-17T08:23:15.103Z INFO  [momentum-bot-1] Position opened: BTCUSDT LONG 0.5 @ 67248.2
2025-06-17T08:31:42.554Z INFO  [funding-arb-2] Funding rate check: ETHUSDT 0.031% < 0.05% threshold, skipping
2025-06-17T08:34:11.220Z ERROR [whale-follow-3] Whale alert API timeout after 5000ms
2025-06-17T08:34:11.221Z WARN  [whale-follow-3] Retrying whale alert fetch (attempt 2/3)
2025-06-17T08:34:16.345Z INFO  [whale-follow-3] Whale alert fetch succeeded on retry
2025-06-17T08:45:00.001Z INFO  [momentum-bot-1] RSI check: BTCUSDT RSI=72.3 > 70, preparing exit
2025-06-17T08:45:00.234Z INFO  [momentum-bot-1] Position closed: BTCUSDT +1.2% pnl=+$403.20
2025-06-17T08:52:33.110Z ERROR [mean-rev-4] Order rejected: insufficient margin (need 5000 USDT, have 3200)
2025-06-17T08:52:33.111Z WARN  [mean-rev-4] Reducing position size from 5000 to 3000 USDT
2025-06-17T09:01:22.440Z INFO  [funding-arb-2] Funding rate check: ETHUSDT 0.052% > 0.05% threshold, opening arb
2025-06-17T09:01:22.890Z INFO  [funding-arb-2] Arb opened: long spot 2 ETH / short perp 2 ETH
2025-06-17T09:15:44.002Z WARN  [momentum-bot-1] Drawdown approaching limit: -3.8% / -5.0%
2025-06-17T09:23:11.330Z INFO  [whale-follow-3] Whale detected: 1250 ETH transfer to Bitget
2025-06-17T09:23:11.555Z INFO  [whale-follow-3] Signal generated: ETHUSDT LONG confidence=0.65
2025-06-17T09:30:00.000Z ERROR [risk-engine] Position size check failed: 25% > 20% max for SOLUSDT
2025-06-17T09:30:00.001Z WARN  [risk-engine] Auto-reducing SOLUSDT position to comply with risk limits`;

export function LogsView() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [rawText, setRawText] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const parseLogs = useCallback((text: string): LogEntry[] => {
    return text
      .split("\n")
      .filter((l) => l.trim())
      .map((line) => {
        const match = line.match(
          /^(\S+)\s+(INFO|WARN|ERROR|DEBUG)\s+\[([^\]]+)\]\s+(.*)$/,
        );
        if (match) {
          return {
            ts: match[1],
            level: match[2] as LogEntry["level"],
            agent: match[3],
            message: match[4],
          };
        }
        return { ts: new Date().toISOString(), level: "INFO" as const, agent: "unknown", message: line };
      });
  }, []);

  const handleFile = useCallback(
    async (file: File) => {
      const text = await file.text();
      setRawText(text);
      setLogs(parseLogs(text));
      setResult(null);
      toast.success(`Loaded ${file.name}`, { description: `${text.split("\n").length} lines` });
    },
    [parseLogs],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile],
  );

  const loadSample = () => {
    setRawText(SAMPLE_LOG);
    setLogs(parseLogs(SAMPLE_LOG));
    setResult(null);
    toast.success("Sample logs loaded");
  };

  const analyze = async () => {
    if (logs.length === 0) {
      toast.error("No logs to analyze");
      return;
    }
    setAnalyzing(true);
    setResult(null);

    // Simulate AI analysis
    await new Promise((r) => setTimeout(r, 1500));

    const errorCount = logs.filter((l) => l.level === "ERROR").length;
    const warningCount = logs.filter((l) => l.level === "WARN").length;
    const agents = new Set(logs.map((l) => l.agent));
    const successRate = Math.round(((logs.length - errorCount) / logs.length) * 100);

    const analysis: AnalysisResult = {
      summary: `Analyzed ${logs.length} log entries from ${agents.size} agents. Found ${errorCount} errors and ${warningCount} warnings. Overall system health is ${successRate > 90 ? "GOOD" : successRate > 75 ? "FAIR" : "POOR"} with ${successRate}% success rate. Key concerns: API timeouts on whale-follow-3, margin management issues on mean-rev-4, and risk limit breaches on SOLUSDT position sizing.`,
      issues: [
        {
          severity: "critical",
          title: "Whale Alert API Timeouts",
          detail: "whale-follow-3 experienced 5000ms timeouts when fetching whale alerts. The retry mechanism succeeded but adds latency. Consider implementing a circuit breaker and caching recent whale alerts to reduce API dependency.",
        },
        {
          severity: "critical",
          title: "Insufficient Margin on mean-rev-4",
          detail: "Order rejected due to insufficient margin (needed 5000 USDT, had 3200). The auto-reduce logic kicked in but this indicates the position sizing module is not accounting for existing exposure correctly.",
        },
        {
          severity: "warning",
          title: "Slippage Threshold Breach",
          detail: "momentum-bot-1 experienced 12bps slippage vs 8bps max threshold. Consider using limit orders or splitting large market orders into smaller chunks to reduce market impact.",
        },
        {
          severity: "warning",
          title: "Risk Limit Breach on SOLUSDT",
          detail: "Position size check failed: 25% > 20% max. The risk engine auto-reduced the position, but this suggests the signal generation module is not respecting pre-trade risk limits.",
        },
        {
          severity: "info",
          title: "Drawdown Approaching Limit",
          detail: "momentum-bot-1 drawdown at -3.8% / -5.0% limit. Consider tightening stop-loss or reducing position size when drawdown exceeds -3%.",
        },
      ],
      recommendations: [
        {
          title: "Implement Circuit Breaker for External APIs",
          detail: "Add a circuit breaker pattern to the whale alert and on-chain data fetchers. After 3 consecutive timeouts, fail fast for 30s before retrying. This prevents cascading latency issues.",
          impact: "high",
        },
        {
          title: "Pre-Trade Margin Validation",
          detail: "Add a margin check before order placement: query account balance and existing exposure, then validate the new position fits within limits. This prevents rejected orders and wasted API calls.",
          impact: "high",
        },
        {
          title: "Smart Order Routing",
          detail: "For orders > $10k, split into TWAP chunks of $2-5k with 1-2s intervals. This reduces slippage by ~40% based on the observed 12bps breach.",
          impact: "medium",
        },
        {
          title: "Risk-Aware Signal Generation",
          detail: "Pass current exposure and risk limits into the signal generation module so it can pre-filter signals that would breach limits. This eliminates the auto-reduce overhead.",
          impact: "medium",
        },
        {
          title: "Adaptive Stop-Loss",
          detail: "Implement a dynamic stop-loss that tightens as drawdown deepens. At -3% DD, reduce stop from 5% to 3%. At -4% DD, reduce to 2%. This protects capital during losing streaks.",
          impact: "low",
        },
      ],
      metrics: {
        totalEntries: logs.length,
        errorCount,
        warningCount,
        agentsAffected: agents.size,
        avgLatencyMs: 245,
        successRate,
      },
      patterns: [
        { pattern: "API timeout + retry", frequency: 3, example: "whale-follow-3: timeout after 5000ms → retry succeeded" },
        { pattern: "Slippage breach", frequency: 2, example: "momentum-bot-1: 12bps > 8bps threshold" },
        { pattern: "Margin rejection", frequency: 1, example: "mean-rev-4: insufficient margin" },
        { pattern: "Risk limit breach", frequency: 1, example: "SOLUSDT 25% > 20% max" },
        { pattern: "Successful signal → execution", frequency: 8, example: "BTCUSDT LONG confidence=0.78 → filled" },
      ],
    };

    setResult(analysis);
    setAnalyzing(false);
    toast.success("Analysis complete", {
      description: `${analysis.issues.length} issues · ${analysis.recommendations.length} recommendations`,
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Upload + log viewer */}
      <div className="lg:col-span-7 space-y-4">
        <Card className="glass p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Upload className="h-4 w-4 text-cyan-400" />
              <h3 className="text-sm font-semibold">Upload Agent Logs</h3>
            </div>
            <Button variant="ghost" size="sm" onClick={loadSample} className="h-7 text-xs">
              <FileText className="h-3 w-3 mr-1" />
              Load Sample
            </Button>
          </div>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={cn(
              "border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer",
              dragOver ? "border-cyan-500/50 bg-cyan-500/5" : "border-white/10 hover:border-white/20",
            )}
            onClick={() => document.getElementById("log-upload")?.click()}
          >
            <input
              id="log-upload"
              type="file"
              accept=".log,.txt,.json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
              }}
            />
            <Upload className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Drop log file here or click to browse
            </p>
            <p className="text-[10px] text-muted-foreground/60 mt-1">
              Supports .log, .txt, .json · Max 10MB
            </p>
          </div>

          {logs.length > 0 && (
            <div className="mt-3 flex items-center justify-between">
              <Badge variant="outline" className="text-xs">
                {logs.length} entries · {new Set(logs.map((l) => l.agent)).size} agents
              </Badge>
              <Button
                size="sm"
                onClick={analyze}
                disabled={analyzing}
                className="bg-violet-500/20 text-violet-300 hover:bg-violet-500/30 border border-violet-500/30"
              >
                {analyzing ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3.5 w-3.5 mr-2" />
                    Analyze with AI
                  </>
                )}
              </Button>
            </div>
          )}
        </Card>

        {logs.length > 0 && (
          <Card className="glass p-0 overflow-hidden">
            <div className="border-b border-white/5 px-4 py-2.5">
              <span className="text-sm font-semibold font-mono">agent.log</span>
            </div>
            <ScrollArea className="max-h-[400px] scrollbar-thin">
              <div className="p-3 font-mono text-[11px] space-y-0.5">
                {logs.map((log, i) => (
                  <div key={i} className="flex gap-2 hover:bg-white/5 px-1 py-0.5 rounded">
                    <span className="text-muted-foreground/60 shrink-0">{log.ts.split("T")[1]?.split(".")[0]}</span>
                    <span
                      className={cn(
                        "shrink-0 font-bold w-12",
                        log.level === "ERROR" && "text-rose-400",
                        log.level === "WARN" && "text-amber-400",
                        log.level === "INFO" && "text-cyan-400",
                        log.level === "DEBUG" && "text-muted-foreground",
                      )}
                    >
                      {log.level}
                    </span>
                    <span className="shrink-0 text-violet-300">[{log.agent}]</span>
                    <span className="text-foreground/80">{log.message}</span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </Card>
        )}
      </div>

      {/* Analysis results */}
      <div className="lg:col-span-5">
        {result ? (
          <AnalysisPanel result={result} />
        ) : (
          <Card className="glass p-8 text-center h-full flex flex-col items-center justify-center">
            <Sparkles className="h-10 w-10 text-muted-foreground/30 mb-3" />
            <p className="text-sm text-muted-foreground">
              Upload logs and click <span className="text-violet-400 font-semibold">Analyze</span> to get AI-powered insights
            </p>
            <p className="text-[10px] text-muted-foreground/60 mt-1">
              Issue detection, pattern recognition, and optimization recommendations
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}

function AnalysisPanel({ result }: { result: AnalysisResult }) {
  return (
    <ScrollArea className="max-h-[700px] scrollbar-thin">
      <div className="space-y-4">
        {/* Summary */}
        <Card className="glass p-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="h-4 w-4 text-violet-400" />
            <h4 className="text-sm font-semibold">AI Summary</h4>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">{result.summary}</p>
        </Card>

        {/* Metrics */}
        <div className="grid grid-cols-3 gap-2">
          <Card className="glass p-2.5">
            <div className="text-[10px] text-muted-foreground">Entries</div>
            <div className="text-lg font-bold tabular-nums">{result.metrics.totalEntries}</div>
          </Card>
          <Card className="glass p-2.5">
            <div className="text-[10px] text-muted-foreground">Errors</div>
            <div className="text-lg font-bold tabular-nums text-rose-400">{result.metrics.errorCount}</div>
          </Card>
          <Card className="glass p-2.5">
            <div className="text-[10px] text-muted-foreground">Success</div>
            <div className="text-lg font-bold tabular-nums text-emerald-400">{result.metrics.successRate}%</div>
          </Card>
        </div>

        {/* Issues */}
        <Card className="glass p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            <h4 className="text-sm font-semibold">Issues Detected ({result.issues.length})</h4>
          </div>
          <div className="space-y-3">
            {result.issues.map((issue, i) => (
              <div key={i} className="border-l-2 pl-3" style={{
                borderColor: issue.severity === "critical" ? "#f43f5e" : issue.severity === "warning" ? "#f59e0b" : "#0ea5e9",
              }}>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold">{issue.title}</span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[9px] px-1 py-0",
                      issue.severity === "critical" && "border-rose-500/30 text-rose-300",
                      issue.severity === "warning" && "border-amber-500/30 text-amber-300",
                      issue.severity === "info" && "border-sky-500/30 text-sky-300",
                    )}
                  >
                    {issue.severity}
                  </Badge>
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground leading-relaxed">{issue.detail}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Recommendations */}
        <Card className="glass p-4">
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="h-4 w-4 text-emerald-400" />
            <h4 className="text-sm font-semibold">Recommendations ({result.recommendations.length})</h4>
          </div>
          <div className="space-y-3">
            {result.recommendations.map((rec, i) => (
              <div key={i} className="rounded-md border border-white/5 bg-white/[0.02] p-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold">{rec.title}</span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[9px] px-1 py-0",
                      rec.impact === "high" && "border-emerald-500/30 text-emerald-300",
                      rec.impact === "medium" && "border-amber-500/30 text-amber-300",
                      rec.impact === "low" && "border-sky-500/30 text-sky-300",
                    )}
                  >
                    {rec.impact} impact
                  </Badge>
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground leading-relaxed">{rec.detail}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Patterns */}
        <Card className="glass p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="h-4 w-4 text-cyan-400" />
            <h4 className="text-sm font-semibold">Patterns</h4>
          </div>
          <div className="space-y-2">
            {result.patterns.map((p, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex-1 min-w-0">
                  <span className="font-medium">{p.pattern}</span>
                  <p className="text-[10px] text-muted-foreground truncate">{p.example}</p>
                </div>
                <Badge variant="outline" className="text-[9px] ml-2 shrink-0">
                  ×{p.frequency}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </ScrollArea>
  );
}
