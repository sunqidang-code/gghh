"use client";

import { useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppStore } from "@/store/app-store";
import { toast } from "sonner";
import { Play, Copy, RotateCcw, Terminal, BookOpen, Zap, Clock, CheckCircle2, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface PlaygroundExample {
  id: string;
  name: string;
  category: "market" | "onchain" | "trading" | "risk";
  description: string;
  code: string;
}

const EXAMPLES: PlaygroundExample[] = [
  {
    id: "ticker",
    name: "Get Ticker",
    category: "market",
    description: "Fetch the latest ticker snapshot for BTCUSDT",
    code: `// Fetch the latest ticker for BTCUSDT
const ticker = await agent.market.getTicker('BTCUSDT');

console.log('Last price:', ticker.lastPr);
console.log('24h change:', ticker.changePct24h + '%');
console.log('24h volume:', ticker.quoteVolume);`,
  },
  {
    id: "candles",
    name: "Get Candles + RSI",
    category: "market",
    description: "Fetch 1h candles and compute RSI(14)",
    code: `// Get 200 1h candles for ETHUSDT
const candles = await agent.market.getCandles('ETHUSDT', '1h', 200);
console.log('Candles fetched:', candles.length);
console.log('Latest close:', candles[candles.length - 1].close);

// Compute RSI(14)
const rsi = await agent.market.getRSI('ETHUSDT', 14, '1h');
console.log('RSI(14):', rsi.toFixed(2));
console.log('Signal:', rsi > 70 ? 'OVERBOUGHT' : rsi < 30 ? 'OVERSOLD' : 'NEUTRAL');`,
  },
  {
    id: "whales",
    name: "Whale Alerts",
    category: "onchain",
    description: "Get recent whale transfers on Ethereum",
    code: `// Get recent whale transfers on Ethereum (min $500k)
const whales = await agent.onchain.getWhaleAlerts({
  chain: 'ethereum',
  minUsd: 500_000,
  limit: 10,
});

console.log('Whale transfers found:', whales.length);
whales.forEach(w => {
  console.log(\`\${w.asset} \${w.valueUsd.toLocaleString()} USD\`);
  console.log(\`  from: \${w.from.slice(0, 10)}... to: \${w.to.slice(0, 10)}...\`);
});`,
  },
  {
    id: "mempool",
    name: "Mempool Monitor",
    category: "onchain",
    description: "Watch pending transactions on Solana",
    code: `// Get pending mempool transactions on Solana
const txs = await agent.onchain.getMempool('solana', 20);

console.log('Pending txs:', txs.length);
const highPriority = txs.filter(t => t.priority === 'high');
console.log('High priority:', highPriority.length);

const totalValue = txs.reduce((sum, t) => sum + t.valueUsd, 0);
console.log('Total value:', totalValue.toLocaleString(), 'USD');`,
  },
  {
    id: "simulate",
    name: "Simulate Order",
    category: "trading",
    description: "Simulate a $50k market buy against the live order book",
    code: `// Simulate a $50,000 market buy of BTCUSDT
const sim = await agent.trading.simulateOrder({
  symbol: 'BTCUSDT',
  side: 'buy',
  sizeUsd: 50_000,
});

console.log('Avg fill price:', sim.avgFillPrice);
console.log('Slippage:', sim.slippageBps + ' bps');
console.log('Filled:', sim.filledUsd + ' / ' + sim.requestedUsd + ' USD');
console.log('Consumed levels:', sim.consumedLevels);
console.log('Fully filled:', sim.fullyFilled);`,
  },
  {
    id: "risk",
    name: "Risk Check",
    category: "risk",
    description: "Run pre-trade risk checks on a position",
    code: `// Run pre-trade risk checks
const risk = await agent.risk.checkPosition({
  symbol: 'BTCUSDT',
  sizeUsd: 10_000,
  leverage: 5,
  accountEquityUsd: 50_000,
  currentExposureUsd: 5_000,
  maxExposureUsd: 100_000,
  fundingRatePct: 0.012,
  volatilityPct: 3.5,
});

console.log('Risk score:', risk.score + '/100');
console.log('Passed:', risk.passed);
risk.checks.forEach(c => {
  console.log(\`  \${c.passed ? '✓' : '✗'} \${c.name}: \${c.detail}\`);
});
if (risk.warnings.length) {
  console.log('Warnings:', risk.warnings);
}`,
  },
  {
    id: "skills",
    name: "List Skills",
    category: "market",
    description: "List all available Skill Hub skills",
    code: `// List all available skills from the Skill Hub
const skills = await agent.listSkills();

console.log('Available skills:', skills.length);
skills.forEach(s => {
  console.log(\`  [\${s.category}] \${s.id} — \${s.description}\`);
});`,
  },
  {
    id: "kelly",
    name: "Kelly Position Sizing",
    category: "risk",
    description: "Compute optimal position size using Kelly criterion",
    code: `// Kelly criterion position sizing
// Strategy: 55% win rate, 1.5:1 win/loss ratio
const winRate = 0.55;
const winLossRatio = 1.5;

const kellyFraction = agent.risk.kellySize(winRate, winLossRatio);
console.log('Kelly fraction:', (kellyFraction * 100).toFixed(2) + '% of equity');

const equity = 50_000;
const positionSize = equity * kellyFraction;
console.log('Position size:', positionSize.toLocaleString(), 'USD');

// Compute stop-loss and take-profit
const entry = 67000;
const stop = agent.risk.computeStopLoss(entry, 'long', 0.03);
const tp = agent.risk.computeTakeProfit(entry, 'long', 0.06);
console.log('Entry:', entry);
console.log('Stop-loss:', stop.toFixed(2));
console.log('Take-profit:', tp.toFixed(2));`,
  },
];

interface ExecutionResult {
  ok: boolean;
  output: string;
  durationMs: number;
  ts: number;
}

export function PlaygroundView() {
  const [selectedExample, setSelectedExample] = useState<PlaygroundExample>(EXAMPLES[0]);
  const [code, setCode] = useState(EXAMPLES[0].code);
  const [result, setResult] = useState<ExecutionResult | null>(null);
  const [running, setRunning] = useState(false);
  const settings = useAppStore((s) => s.settings);

  const runCode = useCallback(async () => {
    setRunning(true);
    setResult(null);
    const start = Date.now();

    try {
      // Simulate SDK execution — in production this would call the actual SDK
      // methods. For the demo we parse the code and return realistic output.
      await new Promise((r) => setTimeout(r, 400 + Math.random() * 600));

      const output = simulateExecution(code, selectedExample.id);
      setResult({
        ok: true,
        output,
        durationMs: Date.now() - start,
        ts: Date.now(),
      });
      toast.success("Execution completed", {
        description: `${Date.now() - start}ms`,
      });
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      setResult({
        ok: false,
        output: `Error: ${errorMsg}`,
        durationMs: Date.now() - start,
        ts: Date.now(),
      });
      toast.error("Execution failed", { description: errorMsg });
    } finally {
      setRunning(false);
    }
  }, [code, selectedExample.id]);

  const selectExample = (ex: PlaygroundExample) => {
    setSelectedExample(ex);
    setCode(ex.code);
    setResult(null);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    toast.success("Code copied to clipboard");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Examples sidebar */}
      <Card className="glass p-0 lg:col-span-3 overflow-hidden">
        <div className="border-b border-white/5 px-4 py-3">
          <div className="flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-semibold">Examples</h3>
          </div>
        </div>
        <ScrollArea className="max-h-[600px] scrollbar-thin">
          <div className="p-2 space-y-1">
            {EXAMPLES.map((ex) => (
              <button
                key={ex.id}
                onClick={() => selectExample(ex)}
                className={cn(
                  "w-full text-left rounded-md p-2 transition-colors",
                  selectedExample.id === ex.id
                    ? "bg-cyan-500/10 border border-cyan-500/20"
                    : "hover:bg-accent/30 border border-transparent",
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold">{ex.name}</span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[9px] px-1 py-0",
                      ex.category === "market" && "border-cyan-500/30 text-cyan-300",
                      ex.category === "onchain" && "border-violet-500/30 text-violet-300",
                      ex.category === "trading" && "border-emerald-500/30 text-emerald-300",
                      ex.category === "risk" && "border-amber-500/30 text-amber-300",
                    )}
                  >
                    {ex.category}
                  </Badge>
                </div>
                <p className="mt-0.5 text-[10px] text-muted-foreground line-clamp-2">
                  {ex.description}
                </p>
              </button>
            ))}
          </div>
        </ScrollArea>
      </Card>

      {/* Editor + output */}
      <div className="lg:col-span-9 space-y-4">
        <Card className="glass p-0 overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/5 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-emerald-400" />
              <span className="text-sm font-semibold font-mono">playground.ts</span>
              <Badge variant="outline" className="text-[9px] ml-1">
                SDK v1.0.0
              </Badge>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" onClick={copyCode} className="h-7 text-xs">
                <Copy className="h-3 w-3 mr-1" />
                Copy
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setCode(selectedExample.code);
                  setResult(null);
                }}
                className="h-7 text-xs"
              >
                <RotateCcw className="h-3 w-3 mr-1" />
                Reset
              </Button>
              <Button
                size="sm"
                onClick={runCode}
                disabled={running}
                className="h-7 text-xs bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30"
              >
                {running ? (
                  <>
                    <div className="h-3 w-3 mr-1 rounded-full border-2 border-emerald-300/30 border-t-emerald-300 animate-spin" />
                    Running
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3 mr-1" />
                    Run
                  </>
                )}
              </Button>
            </div>
          </div>
          <Textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="font-mono text-xs min-h-[280px] bg-transparent border-0 rounded-none focus-visible:ring-0 resize-none scrollbar-thin"
            spellCheck={false}
          />
        </Card>

        {result && (
          <Card className="glass p-0 overflow-hidden animate-fade-in-up">
            <div className="flex items-center justify-between border-b border-white/5 px-4 py-2.5">
              <div className="flex items-center gap-2">
                {result.ok ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                ) : (
                  <XCircle className="h-4 w-4 text-rose-400" />
                )}
                <span className="text-sm font-semibold">Output</span>
                <Badge
                  variant="outline"
                  className={cn(
                    "text-[9px]",
                    result.ok
                      ? "border-emerald-500/30 text-emerald-300"
                      : "border-rose-500/30 text-rose-300",
                  )}
                >
                  {result.ok ? "SUCCESS" : "ERROR"}
                </Badge>
              </div>
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {result.durationMs}ms
                </span>
                <span className="flex items-center gap-1">
                  <Zap className="h-3 w-3" />
                  {settings.productType}
                </span>
              </div>
            </div>
            <pre className="p-4 text-xs font-mono text-emerald-300/90 overflow-x-auto scrollbar-thin whitespace-pre-wrap">
              {result.output}
            </pre>
          </Card>
        )}

        {!result && (
          <Card className="glass p-6 text-center">
            <Terminal className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Select an example and click <span className="text-emerald-400 font-semibold">Run</span> to execute
            </p>
            <p className="text-[10px] text-muted-foreground/60 mt-1">
              The playground simulates SDK calls against live-shaped data — no API key required
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}

function simulateExecution(code: string, exampleId: string): string {
  const lines: string[] = [];

  switch (exampleId) {
    case "ticker": {
      const lastPr = 67245.5 + (Math.random() - 0.5) * 200;
      const changePct = (Math.random() - 0.4) * 6;
      const volume = 1.2e9 + Math.random() * 0.5e9;
      lines.push(`Last price: ${lastPr.toFixed(2)}`);
      lines.push(`24h change: ${changePct.toFixed(2)}%`);
      lines.push(`24h volume: ${volume.toLocaleString(undefined, { maximumFractionDigits: 0 })}`);
      break;
    }
    case "candles": {
      lines.push(`Candles fetched: 200`);
      lines.push(`Latest close: ${(3512 + (Math.random() - 0.5) * 50).toFixed(2)}`);
      const rsi = 30 + Math.random() * 50;
      lines.push(`RSI(14): ${rsi.toFixed(2)}`);
      lines.push(`Signal: ${rsi > 70 ? "OVERBOUGHT" : rsi < 30 ? "OVERSOLD" : "NEUTRAL"}`);
      break;
    }
    case "whales": {
      lines.push(`Whale transfers found: 10`);
      const assets = ["ETH", "USDT", "USDC", "WETH", "WBTC"];
      for (let i = 0; i < 5; i++) {
        const value = 500_000 + Math.random() * 5_000_000;
        lines.push(`${assets[i]} ${value.toLocaleString(undefined, { maximumFractionDigits: 0 })} USD`);
        lines.push(`  from: 0x${Math.random().toString(16).slice(2, 12)}... to: 0x${Math.random().toString(16).slice(2, 12)}...`);
      }
      break;
    }
    case "mempool": {
      lines.push(`Pending txs: 20`);
      lines.push(`High priority: 7`);
      lines.push(`Total value: ${(2_500_000 + Math.random() * 1_000_000).toLocaleString(undefined, { maximumFractionDigits: 0 })} USD`);
      break;
    }
    case "simulate": {
      const avgFill = 67250 + Math.random() * 20;
      const slippage = 1 + Math.random() * 4;
      lines.push(`Avg fill price: ${avgFill.toFixed(2)}`);
      lines.push(`Slippage: ${slippage.toFixed(1)} bps`);
      lines.push(`Filled: 50000 / 50000 USD`);
      lines.push(`Consumed levels: ${Math.ceil(2 + Math.random() * 5)}`);
      lines.push(`Fully filled: true`);
      break;
    }
    case "risk": {
      lines.push(`Risk score: 78/100`);
      lines.push(`Passed: true`);
      lines.push(`  ✓ Leverage: 5x ≤ 20x max`);
      lines.push(`  ✓ Position size: 20.0% ≤ 25.0% of equity`);
      lines.push(`  ✓ Exposure: $15,000 ≤ $100,000 max`);
      lines.push(`  ✓ Funding rate: 0.012% ≤ 0.050% max`);
      lines.push(`  ✓ Volatility: 3.5% ≤ 8.0% max`);
      break;
    }
    case "skills": {
      lines.push(`Available skills: 12`);
      const skills = [
        ["market", "market.ticker", "Fetch latest ticker snapshot"],
        ["market", "market.candles", "Fetch OHLCV candles"],
        ["market", "market.orderbook", "Fetch merged order book"],
        ["onchain", "onchain.whale_alerts", "Get whale transfer alerts"],
        ["onchain", "onchain.mempool", "Monitor pending transactions"],
        ["onchain", "onchain.metrics", "Aggregate on-chain metrics"],
        ["trading", "trading.simulate", "Simulate order execution"],
        ["trading", "trading.place", "Place live order (auth)"],
        ["risk", "risk.check", "Pre-trade risk checks"],
        ["risk", "risk.kelly", "Kelly position sizing"],
      ];
      skills.forEach(([cat, id, desc]) => {
        lines.push(`  [${cat}] ${id} — ${desc}`);
      });
      break;
    }
    case "kelly": {
      lines.push(`Kelly fraction: 8.33% of equity`);
      lines.push(`Position size: 4,166 USD`);
      lines.push(`Entry: 67000`);
      lines.push(`Stop-loss: 64990.00`);
      lines.push(`Take-profit: 71020.00`);
      break;
    }
    default:
      lines.push("// No output");
  }

  return lines.join("\n");
}
