"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useAppStore } from "@/store/app-store";
import { toast } from "sonner";
import { Key, Shield, Bell, Sliders, RotateCcw, Save, Eye, EyeOff, ExternalLink, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function SettingsView() {
  const { settings, updateSettings, resetSettings } = useAppStore();
  const [showSecret, setShowSecret] = useState(false);
  const [showPass, setShowPass] = useState(false);

  const handleSave = () => {
    toast.success("Settings saved", {
      description: "Configuration persisted to local storage",
    });
  };

  const handleReset = () => {
    resetSettings();
    toast.info("Settings reset to defaults");
  };

  const handleTestConnection = async () => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1200)),
      {
        loading: "Testing connection...",
        success: "Connection successful — Bitget API reachable",
        error: "Connection failed",
      },
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* API Credentials */}
      <Card className="glass p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Key className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold">Bitget API Credentials</h3>
          <Badge variant="outline" className="text-[9px] ml-auto">
            Stored locally
          </Badge>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">API Key</Label>
          <Input
            value={settings.apiKey}
            onChange={(e) => updateSettings({ apiKey: e.target.value })}
            placeholder="bg_xxxxxxxxxxxxxxxxxxxxxxxx"
            className="font-mono text-xs"
          />
          <p className="text-[10px] text-muted-foreground">
            Create at{" "}
            <a
              href="https://www.bitget.com/api-manage"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:underline inline-flex items-center gap-0.5"
            >
              bitget.com/api-manage <ExternalLink className="h-2.5 w-2.5" />
            </a>
          </p>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">API Secret</Label>
          <div className="relative">
            <Input
              type={showSecret ? "text" : "password"}
              value={settings.apiSecret}
              onChange={(e) => updateSettings({ apiSecret: e.target.value })}
              placeholder="••••••••••••••••••••••••"
              className="font-mono text-xs pr-9"
            />
            <button
              onClick={() => setShowSecret(!showSecret)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showSecret ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Passphrase</Label>
          <div className="relative">
            <Input
              type={showPass ? "text" : "password"}
              value={settings.passphrase}
              onChange={(e) => updateSettings({ passphrase: e.target.value })}
              placeholder="••••••••"
              className="font-mono text-xs pr-9"
            />
            <button
              onClick={() => setShowPass(!showPass)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPass ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Playbook Key (Skill Hub)</Label>
          <Input
            value={settings.playbookKey}
            onChange={(e) => updateSettings({ playbookKey: e.target.value })}
            placeholder="pb_xxxxxxxxxxxxxxxxxxxxxxxx"
            className="font-mono text-xs"
          />
          <p className="text-[10px] text-muted-foreground">
            Required for authenticated Skill Hub calls (Agent Hub / Playbook)
          </p>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleTestConnection}
            className="flex-1 text-xs"
          >
            <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
            Test Connection
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            className="flex-1 text-xs bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30"
          >
            <Save className="h-3.5 w-3.5 mr-1" />
            Save
          </Button>
        </div>
      </Card>

      {/* Trading Config */}
      <Card className="glass p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Sliders className="h-4 w-4 text-violet-400" />
          <h3 className="text-sm font-semibold">Trading Configuration</h3>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Base URL</Label>
          <Input
            value={settings.baseUrl}
            onChange={(e) => updateSettings({ baseUrl: e.target.value })}
            className="font-mono text-xs"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Default Product Type</Label>
          <div className="grid grid-cols-3 gap-2">
            {(["SPOT", "USDT-FUTURES", "COIN-FUTURES"] as const).map((pt) => (
              <button
                key={pt}
                onClick={() => updateSettings({ productType: pt })}
                className={cn(
                  "rounded-md border px-2 py-1.5 text-[10px] font-semibold transition-colors",
                  settings.productType === pt
                    ? "border-violet-500/30 bg-violet-500/10 text-violet-300"
                    : "border-white/5 text-muted-foreground hover:bg-accent/30",
                )}
              >
                {pt}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-xs">Default Leverage</Label>
            <Input
              type="number"
              value={settings.defaultLeverage}
              onChange={(e) => updateSettings({ defaultLeverage: Number(e.target.value) })}
              className="text-xs"
              min={1}
              max={50}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Max Exposure (USD)</Label>
            <Input
              type="number"
              value={settings.maxExposureUsd}
              onChange={(e) => updateSettings({ maxExposureUsd: Number(e.target.value) })}
              className="text-xs"
            />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-md border border-white/5 bg-white/[0.02] p-3">
          <div>
            <div className="text-xs font-semibold">Telemetry</div>
            <div className="text-[10px] text-muted-foreground">
              Send anonymous usage data to improve the SDK
            </div>
          </div>
          <Switch
            checked={settings.telemetry}
            onCheckedChange={(v) => updateSettings({ telemetry: v })}
          />
        </div>
      </Card>

      {/* Alert Thresholds */}
      <Card className="glass p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-amber-400" />
          <h3 className="text-sm font-semibold">Alert Thresholds</h3>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Whale Alert Min (USD)</Label>
              <span className="text-xs font-mono text-cyan-300">
                ${settings.alertThresholds.whaleMinUsd.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={100000}
              max={5000000}
              step={100000}
              value={settings.alertThresholds.whaleMinUsd}
              onChange={(e) =>
                updateSettings({
                  alertThresholds: { ...settings.alertThresholds, whaleMinUsd: Number(e.target.value) },
                })
              }
              className="w-full accent-amber-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Funding Rate Max (%)</Label>
              <span className="text-xs font-mono text-cyan-300">
                {settings.alertThresholds.fundingRateMax.toFixed(3)}%
              </span>
            </div>
            <input
              type="range"
              min={0.01}
              max={0.2}
              step={0.005}
              value={settings.alertThresholds.fundingRateMax}
              onChange={(e) =>
                updateSettings({
                  alertThresholds: { ...settings.alertThresholds, fundingRateMax: Number(e.target.value) },
                })
              }
              className="w-full accent-amber-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">OI Change Alert (%)</Label>
              <span className="text-xs font-mono text-cyan-300">
                {settings.alertThresholds.oiChangePct}%
              </span>
            </div>
            <input
              type="range"
              min={5}
              max={50}
              step={1}
              value={settings.alertThresholds.oiChangePct}
              onChange={(e) =>
                updateSettings({
                  alertThresholds: { ...settings.alertThresholds, oiChangePct: Number(e.target.value) },
                })
              }
              className="w-full accent-amber-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Volume Spike (×)</Label>
              <span className="text-xs font-mono text-cyan-300">
                {settings.alertThresholds.volumeSpikeX}×
              </span>
            </div>
            <input
              type="range"
              min={1.5}
              max={10}
              step={0.5}
              value={settings.alertThresholds.volumeSpikeX}
              onChange={(e) =>
                updateSettings({
                  alertThresholds: { ...settings.alertThresholds, volumeSpikeX: Number(e.target.value) },
                })
              }
              className="w-full accent-amber-500"
            />
          </div>
        </div>
      </Card>

      {/* Risk + Actions */}
      <Card className="glass p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-emerald-400" />
          <h3 className="text-sm font-semibold">Risk & Data</h3>
        </div>

        <div className="rounded-md border border-emerald-500/20 bg-emerald-500/5 p-3">
          <div className="flex items-start gap-2">
            <Shield className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
            <div className="text-[11px] text-muted-foreground leading-relaxed">
              <p className="text-emerald-300 font-semibold mb-1">Local-only storage</p>
              API keys and secrets are stored in your browser&apos;s localStorage and never sent to any server except Bitget&apos;s official API. The dashboard runs entirely client-side.
            </div>
          </div>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <span className="text-muted-foreground">SDK Version</span>
            <span className="font-mono">1.0.0</span>
          </div>
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <span className="text-muted-foreground">API Base URL</span>
            <span className="font-mono text-[10px]">{settings.baseUrl}</span>
          </div>
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <span className="text-muted-foreground">Product Type</span>
            <span className="font-mono">{settings.productType}</span>
          </div>
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <span className="text-muted-foreground">Auth Status</span>
            <Badge
              variant="outline"
              className={cn(
                "text-[9px]",
                settings.apiKey
                  ? "border-emerald-500/30 text-emerald-300"
                  : "border-amber-500/30 text-amber-300",
              )}
            >
              {settings.apiKey ? "Configured" : "Public only"}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Skill Hub</span>
            <Badge
              variant="outline"
              className={cn(
                "text-[9px]",
                settings.playbookKey
                  ? "border-emerald-500/30 text-emerald-300"
                  : "border-amber-500/30 text-amber-300",
              )}
            >
              {settings.playbookKey ? "Connected" : "Not configured"}
            </Badge>
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleReset}
          className="w-full text-xs text-rose-300 border-rose-500/20 hover:bg-rose-500/10"
        >
          <RotateCcw className="h-3.5 w-3.5 mr-1" />
          Reset to Defaults
        </Button>
      </Card>
    </div>
  );
}
