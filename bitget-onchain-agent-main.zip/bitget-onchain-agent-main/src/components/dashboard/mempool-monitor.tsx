"use client";

import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMempool } from "@/lib/sdk/hooks";
import { ChainIcon, formatUsd, timeAgo } from "@/components/shared";
import { cn } from "@/lib/utils";
import { Layers, Zap } from "lucide-react";
import type { MempoolTx } from "@/lib/sdk/types";

export function MempoolMonitor() {
  const { data: txs, loading } = useMempool("ethereum", 3000);

  return (
    <Card className="glass p-0 overflow-hidden flex flex-col h-full">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <Layers className="h-4 w-4 text-sky-400" />
          <h3 className="text-sm font-semibold">Mempool Monitor</h3>
          <span className="ml-1 rounded-full bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-bold text-sky-300">
            ETH
          </span>
        </div>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
          Pending · 3s
        </span>
      </div>

      <ScrollArea className="flex-1 max-h-[360px] scrollbar-thin">
        <div className="divide-y divide-white/5">
          {loading && !txs
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="p-2.5 h-[52px] shimmer" />
              ))
            : txs?.map((tx) => <MempoolRow key={tx.hash} tx={tx} />)}
        </div>
      </ScrollArea>
    </Card>
  );
}

function MempoolRow({ tx }: { tx: MempoolTx }) {
  const priorityColor =
    tx.priority === "high"
      ? "text-rose-400 bg-rose-500/10"
      : tx.priority === "medium"
        ? "text-amber-400 bg-amber-500/10"
        : "text-zinc-400 bg-zinc-500/10";

  return (
    <div className="flex items-center gap-2 p-2.5 hover:bg-accent/20 transition-colors animate-fade-in-up">
      <ChainIcon chain={tx.chain} className="h-5 w-5 text-[8px]" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-mono text-foreground truncate">{tx.hash.slice(0, 14)}…</span>
          <span className="rounded bg-white/5 px-1 py-0.5 text-[9px] text-muted-foreground">
            {tx.method}
          </span>
        </div>
        <div className="mt-0.5 flex items-center gap-2 text-[9px] text-muted-foreground font-mono">
          <span className="truncate">{tx.from.slice(0, 8)}…</span>
          <span>→</span>
          <span className="truncate">{tx.to.slice(0, 8)}…</span>
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-[11px] font-semibold tabular-nums text-foreground">
          {formatUsd(tx.valueUsd)}
        </div>
        <div className="flex items-center justify-end gap-1 text-[9px] text-muted-foreground">
          <Zap className={cn("h-2.5 w-2.5", priorityColor.split(" ")[0])} />
          <span>{tx.gasPrice} gwei</span>
        </div>
      </div>
    </div>
  );
}
