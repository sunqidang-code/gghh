"use client";

import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAgentSignals, useAgentLogs } from "@/lib/sdk/hooks";
import { cn } from "@/lib/utils";
import { Bot, Brain, Activity, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { timeAgo } from "@/components/shared";
import type { AgentSignal } from "@/lib/sdk/types";

export function AgentMonitor() {
  const { data: signals, loading } = useAgentSignals(6000);
  const { data: logs } = useAgentLogs(5000);

  const activeAgents = new Set(signals?.map((s) => s.agentName)).size;
  const totalPnl = logs?.reduce((sum, l) => sum + (l.pnlUsd ?? 0), 0) ?? 0;

  return (
    <Card className="glass p-0 overflow-hidden flex flex-col h-full">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <Bot className="h-4 w-4 text-violet-400" />
          <h3 className="text-sm font-semibold">Agent Signals</h3>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="text-muted-foreground">
            <span className="text-violet-300 font-bold">{activeAgents}</span> active
          </span>
          <span className="text-muted-foreground">
            PnL{" "}
            <span className={cn("font-bold", totalPnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
              {totalPnl >= 0 ? "+" : ""}${totalPnl.toLocaleString()}
            </span>
          </span>
        </div>
      </div>

      <ScrollArea className="flex-1 max-h-[420px] scrollbar-thin">
        <div className="divide-y divide-white/5">
          {loading && !signals
            ? Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="p-3 h-[120px] shimmer" />
              ))
            : signals?.map((signal) => <SignalRow key={signal.id} signal={signal} />)}
        </div>
      </ScrollArea>
    </Card>
  );
}

function SignalRow({ signal }: { signal: AgentSignal }) {
  const sideIcon =
    signal.side === "long" ? TrendingUp : signal.side === "short" ? TrendingDown : Minus;
  const sideColor =
    signal.side === "long"
      ? "text-emerald-400"
      : signal.side === "short"
        ? "text-rose-400"
        : "text-zinc-400";

  const SideIcon = sideIcon;

  return (
    <div className="p-3 hover:bg-accent/20 transition-colors animate-fade-in-up">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-violet-500/10 border border-violet-500/20">
            <Brain className="h-3.5 w-3.5 text-violet-400" />
          </div>
          <div>
            <div className="text-xs font-semibold">{signal.agentName}</div>
            <div className="text-[10px] text-muted-foreground">{timeAgo(signal.ts)}</div>
          </div>
        </div>
        <div className={cn("flex items-center gap-1 text-xs font-bold", sideColor)}>
          <SideIcon className="h-3 w-3" />
          {signal.side.toUpperCase()}
        </div>
      </div>

      <div className="mt-2 flex items-center gap-2">
        <span className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] font-mono">
          {signal.symbol}
        </span>
        <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
          <div
            className={cn(
              "h-full rounded-full",
              signal.confidence > 0.7
                ? "bg-emerald-500"
                : signal.confidence > 0.4
                  ? "bg-amber-500"
                  : "bg-rose-500",
            )}
            style={{ width: `${signal.confidence * 100}%` }}
          />
        </div>
        <span className="text-[10px] tabular-nums text-muted-foreground">
          {Math.round(signal.confidence * 100)}%
        </span>
      </div>

      <p className="mt-1.5 text-[11px] text-muted-foreground line-clamp-2">{signal.reasoning}</p>

      <div className="mt-1.5 flex flex-wrap gap-1">
        {signal.sources.map((src) => (
          <span
            key={src.label}
            className="rounded bg-white/5 px-1 py-0.5 text-[9px] text-muted-foreground"
          >
            {src.label}
          </span>
        ))}
        <span className="ml-auto flex items-center gap-1 text-[9px] text-muted-foreground">
          <Activity className="h-2.5 w-2.5" />
          Risk {signal.riskScore}/100
        </span>
      </div>
    </div>
  );
}
