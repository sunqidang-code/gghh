"use client";

import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAlerts } from "@/lib/sdk/hooks";
import { SeverityBadge, timeAgo } from "@/components/shared";
import { cn } from "@/lib/utils";
import { Bell, Waves, Flame, TrendingUp, AlertTriangle, Bot, Zap } from "lucide-react";

const CATEGORY_ICONS = {
  whale: Waves,
  funding: Flame,
  volume: TrendingUp,
  open_interest: Gauge,
  price: AlertTriangle,
  liquidation: Zap,
  agent: Bot,
};

function Gauge(props: React.SVGProps<SVGSVGElement>) {
  return <TrendingUp {...props} />;
}

export function AlertStream() {
  const { data: alerts, loading } = useAlerts(4000);

  return (
    <Card className="glass p-0 overflow-hidden flex flex-col h-full">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-amber-400" />
          <h3 className="text-sm font-semibold">Live Alerts</h3>
          <span className="ml-1 rounded-full bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">
            {alerts?.length ?? 0}
          </span>
        </div>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
          Auto-refresh 4s
        </span>
      </div>

      <ScrollArea className="flex-1 max-h-[420px] scrollbar-thin">
        <div className="divide-y divide-white/5">
          {loading && !alerts
            ? Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="p-3 h-[68px] shimmer" />
              ))
            : alerts?.map((alert) => {
                const Icon = CATEGORY_ICONS[alert.category] ?? AlertTriangle;
                return (
                  <div
                    key={alert.id}
                    className="flex items-start gap-3 p-3 hover:bg-accent/20 transition-colors animate-fade-in-up"
                  >
                    <div
                      className={cn(
                        "mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md border",
                        alert.severity === "critical"
                          ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                          : alert.severity === "warning"
                            ? "bg-amber-500/10 border-amber-500/20 text-amber-400"
                            : "bg-sky-500/10 border-sky-500/20 text-sky-400",
                      )}
                    >
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold truncate">{alert.title}</span>
                        <SeverityBadge severity={alert.severity} />
                      </div>
                      <p className="mt-0.5 text-[11px] text-muted-foreground line-clamp-2">
                        {alert.message}
                      </p>
                      <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground/70">
                        {alert.symbol && (
                          <span className="rounded bg-white/5 px-1 py-0.5 font-mono">
                            {alert.symbol}
                          </span>
                        )}
                        <span>{timeAgo(alert.ts)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
        </div>
      </ScrollArea>
    </Card>
  );
}
