"use client";

import { Card } from "@/components/ui/card";
import { useTickers, useWhaleAlerts, useAlerts, useAgentSignals } from "@/lib/sdk/hooks";
import { formatUsd } from "@/components/shared";
import { cn } from "@/lib/utils";
import { DollarSign, Waves, Bell, Bot, TrendingUp } from "lucide-react";

export function StatsBar() {
  const { data: tickers } = useTickers(["BTCUSDT", "ETHUSDT", "SOLUSDT"], 3000);
  const { data: whales } = useWhaleAlerts(50, 5000);
  const { data: alerts } = useAlerts(10000);
  const { data: signals } = useAgentSignals(6000);

  const totalVolume = tickers?.reduce((sum, t) => sum + t.quoteVolume, 0) ?? 0;
  const whaleVolume = whales?.reduce((sum, w) => sum + w.valueUsd, 0) ?? 0;
  const criticalAlerts = alerts?.filter((a) => a.severity === "critical").length ?? 0;
  const activeAgents = new Set(signals?.map((s) => s.agentName)).size;
  const avgConfidence =
    signals && signals.length > 0
      ? signals.reduce((sum, s) => sum + s.confidence, 0) / signals.length
      : 0;

  const stats = [
    {
      label: "24h Volume",
      value: formatUsd(totalVolume),
      sub: "Top 3 markets",
      icon: DollarSign,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10",
    },
    {
      label: "Whale Flow",
      value: formatUsd(whaleVolume),
      sub: `${whales?.length ?? 0} transfers`,
      icon: Waves,
      color: "text-violet-400",
      bg: "bg-violet-500/10",
    },
    {
      label: "Active Alerts",
      value: String(alerts?.length ?? 0),
      sub: `${criticalAlerts} critical`,
      icon: Bell,
      color: "text-amber-400",
      bg: "bg-amber-500/10",
    },
    {
      label: "Agents Online",
      value: String(activeAgents),
      sub: `${Math.round(avgConfidence * 100)}% avg conf`,
      icon: Bot,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.label} className="glass p-3 hover:border-white/20 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                {stat.label}
              </span>
              <div className={cn("flex h-7 w-7 items-center justify-center rounded-md", stat.bg)}>
                <Icon className={cn("h-3.5 w-3.5", stat.color)} />
              </div>
            </div>
            <div className="mt-1.5 text-xl font-bold tabular-nums">{stat.value}</div>
            <div className="text-[10px] text-muted-foreground">{stat.sub}</div>
          </Card>
        );
      })}
    </div>
  );
}

export function TickerTape() {
  const { data: tickers } = useTickers(
    ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "AVAXUSDT", "LINKUSDT", "TONUSDT"],
    3000,
  );

  if (!tickers) return null;

  const items = [...tickers, ...tickers]; // duplicate for seamless scroll

  return (
    <div className="relative overflow-hidden border-y border-white/5 bg-black/20 py-1.5">
      <div className="flex animate-ticker whitespace-nowrap">
        {items.map((t, i) => (
          <span key={`${t.symbol}-${i}`} className="mx-4 inline-flex items-center gap-1.5 text-xs">
            <span className="font-semibold text-foreground">{t.symbol.replace("USDT", "")}</span>
            <span className="tabular-nums text-muted-foreground">
              ${t.lastPr.toLocaleString(undefined, { maximumFractionDigits: t.lastPr < 1 ? 4 : 2 })}
            </span>
            <span
              className={cn(
                "tabular-nums",
                t.changePct24h >= 0 ? "text-emerald-400" : "text-rose-400",
              )}
            >
              {t.changePct24h >= 0 ? "+" : ""}
              {t.changePct24h.toFixed(2)}%
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
