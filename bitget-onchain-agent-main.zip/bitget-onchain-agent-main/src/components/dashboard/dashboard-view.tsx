"use client";

import { StatsBar, TickerTape } from "@/components/dashboard/stats-bar";
import { MarketOverview } from "@/components/dashboard/market-overview";
import { OnchainHeatmap } from "@/components/dashboard/onchain-heatmap";
import { AlertStream } from "@/components/dashboard/alert-stream";
import { WhaleActivity } from "@/components/dashboard/whale-activity";
import { AgentMonitor } from "@/components/dashboard/agent-monitor";
import { MempoolMonitor } from "@/components/dashboard/mempool-monitor";

export function DashboardView() {
  return (
    <div className="space-y-4">
      <TickerTape />
      <StatsBar />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column: market overview + heatmap */}
        <div className="lg:col-span-2 space-y-4">
          <MarketOverview />
          <OnchainHeatmap />
        </div>

        {/* Right column: alerts */}
        <div className="lg:col-span-1">
          <AlertStream />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <WhaleActivity />
        <AgentMonitor />
        <MempoolMonitor />
      </div>
    </div>
  );
}
