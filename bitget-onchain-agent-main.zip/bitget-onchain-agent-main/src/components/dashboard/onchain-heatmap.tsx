"use client";

import { Card } from "@/components/ui/card";
import { useFundingRates, useOpenInterest, useTickers } from "@/lib/sdk/hooks";
import { cn } from "@/lib/utils";
import { Flame, Gauge } from "lucide-react";
import { formatUsd } from "@/components/shared";

const HEAT_SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "SOLUSDT",
  "BNBUSDT",
  "XRPUSDT",
  "DOGEUSDT",
  "ADAUSDT",
  "AVAXUSDT",
  "LINKUSDT",
  "TONUSDT",
];

export function OnchainHeatmap() {
  const { data: tickers } = useTickers(HEAT_SYMBOLS, 4000);
  const { data: funding } = useFundingRates(15000);
  const { data: oi } = useOpenInterest(HEAT_SYMBOLS.slice(0, 5), 15000);

  const cells = HEAT_SYMBOLS.map((symbol) => {
    const ticker = tickers?.find((t) => t.symbol === symbol);
    const fund = funding?.find((f) => f.symbol === symbol);
    const oiData = oi?.find((o) => o.symbol === symbol);
    return {
      symbol,
      changePct: ticker?.changePct24h ?? 0,
      volume: ticker?.quoteVolume ?? 0,
      funding: fund?.fundingRate ?? 0,
      oi: oiData?.openInterestUsd ?? 0,
    };
  });

  return (
    <Card className="glass p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Flame className="h-4 w-4 text-orange-400" />
          <h3 className="text-sm font-semibold">Market Heatmap</h3>
        </div>
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-sm bg-rose-500/70" /> Bearish
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-sm bg-zinc-500/40" /> Neutral
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-sm bg-emerald-500/70" /> Bullish
          </span>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-1.5">
        {cells.map((cell) => {
          const intensity = Math.min(Math.abs(cell.changePct) / 8, 1);
          const isUp = cell.changePct >= 0;
          const bg = isUp
            ? `rgba(16, 185, 129, ${0.15 + intensity * 0.55})`
            : `rgba(244, 63, 94, ${0.15 + intensity * 0.55})`;
          return (
            <div
              key={cell.symbol}
              className="group relative aspect-square rounded-md border border-white/5 p-1.5 transition-all hover:scale-105 hover:border-white/20 cursor-pointer"
              style={{ background: bg }}
            >
              <div className="text-[10px] font-bold text-white/90">
                {cell.symbol.replace("USDT", "")}
              </div>
              <div className="text-[9px] text-white/70 tabular-nums">
                {cell.changePct >= 0 ? "+" : ""}
                {cell.changePct.toFixed(1)}%
              </div>
              <div className="absolute inset-x-1 bottom-1 text-[8px] text-white/50 tabular-nums">
                {formatUsd(cell.volume)}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <div className="rounded-md border border-white/5 bg-white/[0.02] p-2">
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <Gauge className="h-3 w-3" /> Funding Rates
          </div>
          <div className="mt-1 space-y-0.5">
            {funding?.slice(0, 4).map((f) => (
              <div key={f.symbol} className="flex items-center justify-between text-[10px]">
                <span className="text-muted-foreground">{f.symbol.replace("USDT", "")}</span>
                <span
                  className={cn(
                    "tabular-nums font-medium",
                    f.fundingRate >= 0 ? "text-emerald-400" : "text-rose-400",
                  )}
                >
                  {f.fundingRate >= 0 ? "+" : ""}
                  {(f.fundingRate * 100).toFixed(4)}%
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-md border border-white/5 bg-white/[0.02] p-2">
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <Gauge className="h-3 w-3" /> Open Interest
          </div>
          <div className="mt-1 space-y-0.5">
            {oi?.map((o) => (
              <div key={o.symbol} className="flex items-center justify-between text-[10px]">
                <span className="text-muted-foreground">{o.symbol.replace("USDT", "")}</span>
                <span className="tabular-nums font-medium text-foreground">
                  {formatUsd(o.openInterestUsd)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
