"use client";

import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useWhaleAlerts } from "@/lib/sdk/hooks";
import { ChainIcon, formatUsd, timeAgo } from "@/components/shared";
import { Waves, ArrowRight } from "lucide-react";
import type { WhaleAlert } from "@/lib/sdk/types";

export function WhaleActivity() {
  const { data: whales, loading } = useWhaleAlerts(20, 5000);

  return (
    <Card className="glass p-0 overflow-hidden flex flex-col h-full">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <Waves className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold">Whale Activity</h3>
          <span className="ml-1 rounded-full bg-cyan-500/15 px-1.5 py-0.5 text-[10px] font-bold text-cyan-300">
            {whales?.length ?? 0}
          </span>
        </div>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
          Multi-chain
        </span>
      </div>

      <ScrollArea className="flex-1 max-h-[420px] scrollbar-thin">
        <div className="divide-y divide-white/5">
          {loading && !whales
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="p-3 h-[64px] shimmer" />
              ))
            : whales?.map((w) => <WhaleRow key={w.id} whale={w} />)}
        </div>
      </ScrollArea>
    </Card>
  );
}

function WhaleRow({ whale }: { whale: WhaleAlert }) {
  const isExchangeFlow = whale.fromType === "exchange" || whale.toType === "exchange";
  const isInflow = whale.toType === "exchange";
  const isOutflow = whale.fromType === "exchange";

  return (
    <div className="flex items-center gap-3 p-3 hover:bg-accent/20 transition-colors animate-fade-in-up">
      <ChainIcon chain={whale.chain} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-semibold text-foreground">
            {formatUsd(whale.valueUsd)}
          </span>
          <span className="text-[10px] text-muted-foreground">·</span>
          <span className="text-[10px] text-muted-foreground">{whale.asset}</span>
          {isExchangeFlow && (
            <span
              className={`rounded px-1 py-0.5 text-[9px] font-bold uppercase ${
                isInflow
                  ? "bg-rose-500/15 text-rose-300"
                  : isOutflow
                    ? "bg-emerald-500/15 text-emerald-300"
                    : "bg-sky-500/15 text-sky-300"
              }`}
            >
              {isInflow ? "Inflow" : isOutflow ? "Outflow" : "Transfer"}
            </span>
          )}
        </div>
        <div className="mt-0.5 flex items-center gap-1 text-[10px] text-muted-foreground font-mono">
          <span className="truncate">{shorten(whale.from)}</span>
          <ArrowRight className="h-2.5 w-2.5 shrink-0" />
          <span className="truncate">{shorten(whale.to)}</span>
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-[10px] text-muted-foreground">{timeAgo(whale.ts)}</div>
        <div className="text-[9px] text-muted-foreground/60">{whale.txHash.slice(0, 8)}</div>
      </div>
    </div>
  );
}

function shorten(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}
