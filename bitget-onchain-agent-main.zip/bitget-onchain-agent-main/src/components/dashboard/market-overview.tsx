"use client";

import { Card } from "@/components/ui/card";
import { useTickers } from "@/lib/sdk/hooks";
import { PriceChange, formatUsd, LiveDot } from "@/components/shared";
import { cn } from "@/lib/utils";
import { TrendingUp, Activity } from "lucide-react";

const WATCH_SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "SOLUSDT",
  "BNBUSDT",
  "XRPUSDT",
  "DOGEUSDT",
  "ADAUSDT",
  "AVAXUSDT",
];

export function MarketOverview() {
  const { data: tickers, loading } = useTickers(WATCH_SYMBOLS, 3000);

  return (
    <Card className="glass p-0 overflow-hidden">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold">Market Overview</h3>
          <LiveDot className="ml-1" />
        </div>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
          USDT-PERP · Live
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-px bg-white/5">
        {loading && !tickers
          ? Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-card p-3 h-[88px] shimmer" />
            ))
          : tickers?.map((t) => (
              <TickerCell key={t.symbol} ticker={t} />
            ))}
      </div>
    </Card>
  );
}

function TickerCell({ ticker }: { ticker: ReturnType<typeof useTickers>["data"] extends (infer T)[] | undefined ? T : never }) {
  const isUp = ticker.changePct24h >= 0;
  return (
    <div className="bg-card p-3 hover:bg-accent/30 transition-colors">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-foreground">{ticker.symbol.replace("USDT", "")}</span>
        <PriceChange value={ticker.changePct24h} className="text-[10px]" />
      </div>
      <div className="mt-1 text-base font-bold tabular-nums">
        ${ticker.lastPr.toLocaleString(undefined, { maximumFractionDigits: ticker.lastPr < 1 ? 4 : 2 })}
      </div>
      <div className="mt-0.5 flex items-center gap-1 text-[10px] text-muted-foreground">
        <TrendingUp className={cn("h-3 w-3", isUp ? "text-emerald-400" : "text-rose-400 rotate-180")} />
        <span>Vol {formatUsd(ticker.quoteVolume)}</span>
      </div>
    </div>
  );
}
