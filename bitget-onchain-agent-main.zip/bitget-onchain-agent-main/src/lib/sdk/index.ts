/**
 * @bitget-onchain-agent/sdk
 *
 * Agent tooling framework for Bitget + on-chain data.
 * Designed for Bitget AI Hackathon Track 2 (Trading Infra).
 *
 * ## Quick start
 *
 * ```ts
 * import { createAgent } from '@bitget-onchain-agent/sdk';
 *
 * const agent = createAgent({
 *   apiKey: process.env.BITGET_API_KEY,
 *   playbookKey: process.env.BITGET_PLAYBOOK_KEY,
 * });
 *
 * // Market data
 * const ticker = await agent.market.getTicker('BTCUSDT');
 * const candles = await agent.market.getCandles('ETHUSDT', '1h', 200);
 *
 * // On-chain
 * const whales = await agent.onchain.getWhaleAlerts({ chain: 'ethereum', minUsd: 500_000 });
 *
 * // Risk
 * const risk = await agent.risk.checkPosition({
 *   symbol: 'BTCUSDT', sizeUsd: 10_000, leverage: 5,
 * });
 *
 * // Simulate execution
 * const sim = await agent.trading.simulateOrder({
 *   symbol: 'BTCUSDT', side: 'buy', sizeUsd: 50_000,
 * });
 * ```
 *
 * ## React hooks
 *
 * ```tsx
 * import { useTickers, useWhaleAlerts } from '@bitget-onchain-agent/sdk/hooks';
 *
 * function Dashboard() {
 *   const { data: tickers } = useTickers(['BTCUSDT', 'ETHUSDT'], 3000);
 *   const { data: whales } = useWhaleAlerts(20, 5000);
 *   // ...
 * }
 * ```
 */

export { BitgetOnChainAgent, createAgent } from "./client";
export { BitgetRestClient } from "../bitget/rest";
export { SkillHubAdapter } from "./skills/skill-hub";
export { MarketDataSkill } from "./skills/market-data";
export { OnChainSkill } from "./skills/onchain";
export { TradingSkill } from "./skills/trading";
export { RiskSkill } from "./skills/risk";

export * from "./types";

// Version metadata
export const SDK_VERSION = "1.0.0";
export const SDK_NAME = "@bitget-onchain-agent/sdk";
