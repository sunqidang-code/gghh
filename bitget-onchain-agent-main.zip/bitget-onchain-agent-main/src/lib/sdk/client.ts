/**
 * Bitget OnChain Agent SDK — Main Client
 *
 * The `BitgetOnChainAgent` class is the single entry point for the SDK.
 * It wires together the Bitget REST client, the Skill Hub adapter, the
 * on-chain data layer, the risk engine, and the backtest engine.
 *
 * Usage:
 *   import { BitgetOnChainAgent } from '@bitget-onchain-agent/sdk';
 *   const agent = new BitgetOnChainAgent({ apiKey: '...', playbookKey: '...' });
 *   const ticker = await agent.market.getTicker('BTCUSDT');
 *   const whales = await agent.onchain.getWhaleAlerts({ chain: 'ethereum', minUsd: 500_000 });
 *   const risk = await agent.risk.checkPosition({ symbol: 'BTCUSDT', sizeUsd: 10_000, leverage: 5 });
 */

import { BitgetRestClient } from "../bitget/rest";
import { MarketDataSkill } from "./skills/market-data";
import { OnChainSkill } from "./skills/onchain";
import { TradingSkill } from "./skills/trading";
import { RiskSkill } from "./skills/risk";
import { SkillHubAdapter } from "./skills/skill-hub";
import type { SdkConfig, SdkResult } from "./types";

export class BitgetOnChainAgent {
  readonly config: Required<
    Pick<SdkConfig, "baseUrl" | "timeout" | "productType" | "telemetry">
  > &
    Pick<SdkConfig, "apiKey" | "apiSecret" | "passphrase" | "playbookKey" | "logger">;

  readonly rest: BitgetRestClient;
  readonly skillHub: SkillHubAdapter;

  /** Market data skill — tickers, candles, order book, trades */
  readonly market: MarketDataSkill;
  /** On-chain skill — whale alerts, mempool, large transfers, on-chain metrics */
  readonly onchain: OnChainSkill;
  /** Trading skill — simulate execution, place/cancel (auth required) */
  readonly trading: TradingSkill;
  /** Risk skill — pre-trade checks, position sizing, exposure limits */
  readonly risk: RiskSkill;

  constructor(config: SdkConfig = {}) {
    this.config = {
      apiKey: config.apiKey,
      apiSecret: config.apiSecret,
      passphrase: config.passphrase,
      playbookKey: config.playbookKey,
      baseUrl: config.baseUrl ?? "https://api.bitget.com",
      timeout: config.timeout ?? 12_000,
      productType: config.productType ?? "USDT-FUTURES",
      telemetry: config.telemetry ?? false,
      logger: config.logger,
    };

    this.rest = new BitgetRestClient({
      baseUrl: this.config.baseUrl,
      timeout: this.config.timeout,
      fetchImpl: config.fetchImpl,
    });

    this.skillHub = new SkillHubAdapter({
      playbookKey: this.config.playbookKey,
      logger: this.config.logger,
    });

    this.market = new MarketDataSkill(this.rest, this.config);
    this.onchain = new OnChainSkill(this.skillHub, this.config);
    this.trading = new TradingSkill(this.rest, this.config);
    this.risk = new RiskSkill(this.config);
  }

  /** Wrap any async operation in a standardized SdkResult envelope. */
  static async wrap<T>(fn: () => Promise<T>): Promise<SdkResult<T>> {
    const start = Date.now();
    try {
      const data = await fn();
      return {
        ok: true,
        data,
        durationMs: Date.now() - start,
      };
    } catch (err) {
      const error = err instanceof Error ? err.message : String(err);
      return {
        ok: false,
        error,
        durationMs: Date.now() - start,
      };
    }
  }

  /** Health check — pings Bitget public endpoint. */
  async healthCheck(): Promise<SdkResult<{ status: string; latencyMs: number }>> {
    return BitgetOnChainAgent.wrap(async () => {
      const start = Date.now();
      await this.rest.getSpotTickers();
      return { status: "ok", latencyMs: Date.now() - start };
    });
  }

  /** List all available skills (local + Skill Hub). */
  async listSkills() {
    return this.skillHub.listSkills();
  }
}

/**
 * Convenience factory — creates a client configured from environment variables.
 * Works in Node/Bun/Edge. In the browser, pass config explicitly.
 */
export function createAgent(config?: SdkConfig): BitgetOnChainAgent {
  const envConfig: SdkConfig = {
    apiKey: process?.env?.BITGET_API_KEY,
    apiSecret: process?.env?.BITGET_API_SECRET,
    passphrase: process?.env?.BITGET_PASSPHRASE,
    playbookKey: process?.env?.BITGET_PLAYBOOK_KEY,
    baseUrl: process?.env?.BITGET_BASE_URL,
  };
  return new BitgetOnChainAgent({ ...envConfig, ...config });
}
