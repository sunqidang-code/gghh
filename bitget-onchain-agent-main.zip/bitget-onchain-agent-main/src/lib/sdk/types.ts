/**
 * Bitget OnChain Agent SDK — Core Type Definitions
 * @bitget-onchain-agent/sdk
 *
 * All public types exported by the SDK live here. Consumers should import
 * types from the package root: `import type { Ticker, WhaleAlert } from '@bitget-onchain-agent/sdk'`.
 */

/* ------------------------------------------------------------------ */
/* Product / Market                                                    */
/* ------------------------------------------------------------------ */

export type ProductType = "SPOT" | "USDT-FUTURES" | "COIN-FUTURES" | "SWAP";

export type SymbolStatus = "TRADING" | "HALTED" | "DELISTED";

export interface SymbolInfo {
  symbol: string;
  baseCoin: string;
  quoteCoin: string;
  minSize: number;
  maxSize: number;
  sizeIncrement: number;
  priceIncrement: number;
  status: SymbolStatus;
  productType: ProductType;
}

export interface Ticker {
  symbol: string;
  lastPr: number;
  askPr: number;
  bidPr: number;
  bidSz: number;
  askSz: number;
  high24h: number;
  low24h: number;
  change24h: number;
  changePct24h: number;
  baseVolume: number;
  quoteVolume: number;
  ts: number;
}

export interface Candle {
  ts: number; // open time (ms)
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number; // base volume
  quoteVolume?: number;
}

export type CandleInterval =
  | "1m"
  | "5m"
  | "15m"
  | "30m"
  | "1h"
  | "4h"
  | "1d"
  | "1w";

export interface OrderBookLevel {
  price: number;
  size: number;
}

export interface OrderBook {
  symbol: string;
  asks: OrderBookLevel[];
  bids: OrderBookLevel[];
  ts: number;
}

export interface Trade {
  symbol: string;
  tradeId: string;
  price: number;
  size: number;
  side: "buy" | "sell";
  ts: number;
}

/* ------------------------------------------------------------------ */
/* Derivatives                                                         */
/* ------------------------------------------------------------------ */

export interface FundingRate {
  symbol: string;
  fundingRate: number; // decimal, e.g. 0.0001 = 0.01%
  nextFundingTime: number; // ms
  fundingInterval: number; // hours, typically 8
  ts: number;
}

export interface OpenInterest {
  symbol: string;
  openInterest: number; // base units
  openInterestUsd: number;
  ts: number;
}

export interface MarkPrice {
  symbol: string;
  markPrice: number;
  indexPrice: number;
  ts: number;
}

/* ------------------------------------------------------------------ */
/* On-chain                                                            */
/* ------------------------------------------------------------------ */

export type ChainId = "solana" | "ethereum" | "bitcoin" | "base" | "arbitrum" | "bsc";

export interface WhaleAlert {
  id: string;
  chain: ChainId;
  asset: string;
  amount: number;
  amountUsd: number;
  /** Alias for amountUsd — used by UI components for convenience */
  valueUsd: number;
  from: string;
  to: string;
  fromType?: "exchange" | "wallet" | "contract" | "unknown";
  toType?: "exchange" | "wallet" | "contract" | "unknown";
  fromLabel?: string;
  toLabel?: string;
  txHash: string;
  ts: number;
  severity: "info" | "warning" | "critical";
}

export interface LargeTransfer extends WhaleAlert {
  direction: "in" | "out" | "internal";
  exchange?: string;
}

export interface MempoolTx {
  chain: ChainId;
  hash: string;
  txHash: string;
  from: string;
  to: string;
  value: number;
  valueUsd: number;
  gasPrice: number;
  method?: string;
  ts: number;
  priority: "low" | "medium" | "high";
}

export interface OnChainMetric {
  chain: ChainId;
  metric: string; // e.g. "active_addresses", "tx_count", "stablecoin_inflow"
  value: number;
  changePct24h: number;
  ts: number;
}

/* ------------------------------------------------------------------ */
/* Agent / Skill Hub                                                   */
/* ------------------------------------------------------------------ */

export interface SkillDescriptor {
  id: string;
  name: string;
  category: "market" | "onchain" | "trading" | "risk" | "macro" | "sentiment";
  description: string;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
  cost: number; // credits per call
  latencyMs: number; // p50 latency
}

export interface SkillInvocation<TInput = unknown, TOutput = unknown> {
  skillId: string;
  input: TInput;
  output?: TOutput;
  status: "pending" | "running" | "success" | "error";
  error?: string;
  startedAt: number;
  finishedAt?: number;
  durationMs?: number;
  creditsUsed?: number;
}

export interface AgentSignal {
  id: string;
  agentId: string;
  agentName: string;
  symbol: string;
  side: "long" | "short" | "neutral";
  confidence: number; // 0..1
  reasoning: string;
  suggestedAction: string;
  riskScore: number; // 0..100
  ts: number;
  sources: SignalSource[];
}

export interface SignalSource {
  type: "onchain" | "technical" | "macro" | "sentiment" | "funding" | "orderflow";
  label: string;
  weight: number; // 0..1
  value: string;
}

export interface AgentExecutionLog {
  id: string;
  agentId: string;
  agentName: string;
  action: string;
  symbol: string;
  status: "success" | "failed" | "pending";
  pnlUsd?: number;
  durationMs: number;
  ts: number;
  message: string;
  metadata?: Record<string, unknown>;
}

/* ------------------------------------------------------------------ */
/* Risk / Backtest                                                     */
/* ------------------------------------------------------------------ */

export interface RiskCheckResult {
  passed: boolean;
  score: number; // 0..100, higher = safer
  checks: RiskCheck[];
  warnings: string[];
}

export interface RiskCheck {
  name: string;
  passed: boolean;
  detail: string;
  severity: "info" | "warning" | "critical";
}

export interface BacktestConfig {
  symbol: string;
  interval: CandleInterval;
  startTime: number;
  endTime: number;
  initialCapital: number;
  positionSizePct: number; // 0..1
  stopLossPct: number; // 0..1
  takeProfitPct: number; // 0..1
  maxLeverage: number;
  feeRate: number; // taker fee, decimal
  slippageBps: number;
}

export interface BacktestTrade {
  id: string;
  entryTs: number;
  exitTs: number;
  side: "long" | "short";
  entryPrice: number;
  exitPrice: number;
  size: number;
  pnlUsd: number;
  pnlPct: number;
  returnPct: number;
  reason: "take_profit" | "stop_loss" | "signal_exit" | "end_of_data";
}

export interface BacktestResult {
  config: BacktestConfig;
  trades: BacktestTrade[];
  metrics: BacktestMetrics;
  equityCurve: { ts: number; equity: number; drawdown: number }[];
  signalScore: number; // 0..100, on-chain + technical composite
}

export interface BacktestMetrics {
  totalReturnPct: number;
  annualizedReturnPct: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPct: number;
  winRate: number;
  profitFactor: number;
  totalTrades: number;
  avgWinUsd: number;
  avgLossUsd: number;
  exposurePct: number;
}

/* ------------------------------------------------------------------ */
/* Alerts                                                              */
/* ------------------------------------------------------------------ */

export type AlertSeverity = "info" | "warning" | "critical";
export type AlertCategory =
  | "whale"
  | "funding"
  | "volume"
  | "open_interest"
  | "price"
  | "liquidation"
  | "agent";

export interface Alert {
  id: string;
  category: AlertCategory;
  severity: AlertSeverity;
  title: string;
  message: string;
  symbol?: string;
  chain?: ChainId;
  value?: number;
  threshold?: number;
  ts: number;
  acknowledged: boolean;
}

/* ------------------------------------------------------------------ */
/* SDK Configuration                                                   */
/* ------------------------------------------------------------------ */

export interface SdkConfig {
  /** Bitget API key (required for private endpoints; public data works without) */
  apiKey?: string;
  /** Bitget API secret */
  apiSecret?: string;
  /** Bitget passphrase set during API key creation */
  passphrase?: string;
  /** Playbook key for Skill Hub authenticated calls */
  playbookKey?: string;
  /** Base URL override (defaults to https://api.bitget.com) */
  baseUrl?: string;
  /** Request timeout in ms */
  timeout?: number;
  /** Default product type */
  productType?: ProductType;
  /** Enable telemetry / usage tracking */
  telemetry?: boolean;
  /** Custom fetch implementation (for tests / edge runtimes) */
  fetchImpl?: typeof fetch;
  /** Logger */
  logger?: (level: "info" | "warn" | "error", msg: string, meta?: unknown) => void;
}

export interface SdkResult<T> {
  ok: boolean;
  data?: T;
  error?: string;
  statusCode?: number;
  durationMs: number;
  fromCache?: boolean;
  creditsUsed?: number;
}
