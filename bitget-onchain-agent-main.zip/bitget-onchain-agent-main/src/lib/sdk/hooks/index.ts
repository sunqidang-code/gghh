"use client";

/**
 * React Hooks for the Bitget OnChain Agent SDK.
 *
 * These hooks wrap the SDK in idiomatic React patterns (TanStack Query-style
 * state machine) so dashboard components can subscribe to live data with
 * automatic polling, caching, and error handling.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import type {
  AgentExecutionLog,
  AgentSignal,
  Alert,
  BacktestResult,
  Candle,
  ChainId,
  FundingRate,
  MempoolTx,
  OpenInterest,
  Ticker,
  WhaleAlert,
} from "../types";
import { generateMockTickers, generateMockCandles, generateMockFundingRates, generateMockOpenInterest, generateMockWhaleAlerts, generateMockAlerts, generateMockAgentSignals, generateMockAgentLogs, generateMockMempool } from "../../mock/data";

export interface QueryState<T> {
  data: T | undefined;
  loading: boolean;
  error: string | undefined;
  refetch: () => void;
}

/**
 * Polling hook — calls `fetcher` every `intervalMs` and merges results.
 */
function usePolling<T>(
  fetcher: () => Promise<T>,
  intervalMs: number,
  deps: unknown[] = [],
): QueryState<T> {
  const [state, setState] = useState<{
    data: T | undefined;
    loading: boolean;
    error: string | undefined;
  }>({ data: undefined, loading: true, error: undefined });
  const [tick, setTick] = useState(0);
  const fetcherRef = useRef(fetcher);

  useEffect(() => {
    fetcherRef.current = fetcher;
  });

  const refetch = useCallback(() => setTick((t) => t + 1), []);

  useEffect(() => {
    let cancelled = false;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- legitimate data-fetching pattern
    setState((s) => ({ ...s, loading: true }));
    fetcherRef.current()
      .then((d) => {
        if (!cancelled) {
          setState({ data: d, loading: false, error: undefined });
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setState((s) => ({ ...s, loading: false, error: err instanceof Error ? err.message : String(err) }));
        }
      });
    return () => {
      cancelled = true;
    };
  }, [tick, ...deps]);

  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);

  return { data: state.data, loading: state.loading, error: state.error, refetch };
}

/* ------------------------------------------------------------------ */
/* Market data hooks                                                  */
/* ------------------------------------------------------------------ */

export function useTickers(symbols: string[] = ["BTCUSDT", "ETHUSDT", "SOLUSDT"], intervalMs = 3000): QueryState<Ticker[]> {
  return usePolling(
    async () => generateMockTickers(symbols),
    intervalMs,
    [symbols.join(",")],
  );
}

export function useCandles(symbol: string, granularity = "1h", limit = 100, intervalMs = 10000): QueryState<Candle[]> {
  return usePolling(
    async () => generateMockCandles(symbol, limit),
    intervalMs,
    [symbol, granularity, limit],
  );
}

export function useFundingRates(intervalMs = 15000): QueryState<FundingRate[]> {
  return usePolling(
    async () => generateMockFundingRates(),
    intervalMs,
  );
}

export function useOpenInterest(symbols: string[] = ["BTCUSDT", "ETHUSDT", "SOLUSDT"], intervalMs = 15000): QueryState<OpenInterest[]> {
  return usePolling(
    async () => generateMockOpenInterest(symbols),
    intervalMs,
    [symbols.join(",")],
  );
}

/* ------------------------------------------------------------------ */
/* On-chain hooks                                                     */
/* ------------------------------------------------------------------ */

export function useWhaleAlerts(limit = 20, intervalMs = 5000): QueryState<WhaleAlert[]> {
  return usePolling(
    async () => generateMockWhaleAlerts(limit),
    intervalMs,
    [limit],
  );
}

export function useAlerts(intervalMs = 4000): QueryState<Alert[]> {
  return usePolling(
    async () => generateMockAlerts(),
    intervalMs,
  );
}

/* ------------------------------------------------------------------ */
/* Agent hooks                                                        */
/* ------------------------------------------------------------------ */

export function useMempool(chain: ChainId = "ethereum", intervalMs = 3000): QueryState<MempoolTx[]> {
  return usePolling(
    async () => generateMockMempool(chain, 15),
    intervalMs,
    [chain],
  );
}

export function useAgentSignals(intervalMs = 6000): QueryState<AgentSignal[]> {
  return usePolling(
    async () => generateMockAgentSignals(),
    intervalMs,
  );
}

export function useAgentLogs(intervalMs = 5000): QueryState<AgentExecutionLog[]> {
  return usePolling(
    async () => generateMockAgentLogs(),
    intervalMs,
  );
}

/* ------------------------------------------------------------------ */
/* Backtest hook (one-shot)                                          */
/* ------------------------------------------------------------------ */

export function useBacktest() {
  const [result, setResult] = useState<BacktestResult | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);

  const run = useCallback(async (config: unknown) => {
    setLoading(true);
    setError(undefined);
    try {
      // Import dynamically to keep the bundle small
      const { runMockBacktest } = await import("../../mock/backtest");
      const res = runMockBacktest(config as Parameters<typeof runMockBacktest>[0]);
      setResult(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }, []);

  return { result, loading, error, run };
}
