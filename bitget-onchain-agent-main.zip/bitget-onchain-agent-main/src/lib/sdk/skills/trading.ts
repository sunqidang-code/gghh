/**
 * Trading Skill
 *
 * Provides order simulation (no auth required) and a thin wrapper around
 * authenticated order placement (requires API key + secret + passphrase).
 *
 * The simulate function walks the live order book to estimate fill price,
 * slippage, and notional — useful for pre-trade analysis and backtesting.
 */

import type { BitgetRestClient } from "../../bitget/rest";
import type { OrderBook, ProductType, SdkConfig } from "../types";

type ResolvedConfig = Required<
  Pick<SdkConfig, "productType" | "telemetry">
> & Pick<SdkConfig, "apiKey" | "apiSecret" | "passphrase" | "logger">;

export interface SimulateOrderInput {
  symbol: string;
  side: "buy" | "sell";
  sizeUsd: number;
  productType?: ProductType;
  /** Optional pre-fetched order book (saves a round-trip). */
  orderBook?: OrderBook;
}

export interface SimulateOrderResult {
  symbol: string;
  side: "buy" | "sell";
  requestedUsd: number;
  filledUsd: number;
  avgFillPrice: number;
  midPrice: number;
  slippageBps: number;
  filledBase: number;
  consumedLevels: number;
  fullyFilled: boolean;
}

export class TradingSkill {
  constructor(
    private readonly rest: BitgetRestClient,
    private readonly config: ResolvedConfig,
  ) {}

  /**
   * Simulate a market order against the live order book.
   * Returns estimated fill price, slippage in bps, and notional.
   */
  async simulateOrder(input: SimulateOrderInput): Promise<SimulateOrderResult> {
    const productType = input.productType ?? this.config.productType;
    const book = input.orderBook ?? (await this.rest.getOrderBook(input.symbol, productType));

    const levels = input.side === "buy" ? book.asks : book.bids;
    if (levels.length === 0) {
      throw new Error(`No ${input.side} levels in order book for ${input.symbol}`);
    }

    const bestBid = book.bids[0]?.price ?? 0;
    const bestAsk = book.asks[0]?.price ?? 0;
    const midPrice = (bestBid + bestAsk) / 2 || levels[0].price;

    let remainingUsd = input.sizeUsd;
    let filledBase = 0;
    let filledUsd = 0;
    let consumedLevels = 0;

    for (const lvl of levels) {
      const lvlUsd = lvl.price * lvl.size;
      if (lvlUsd >= remainingUsd) {
        const baseToFill = remainingUsd / lvl.price;
        filledBase += baseToFill;
        filledUsd += remainingUsd;
        remainingUsd = 0;
        consumedLevels++;
        break;
      } else {
        filledBase += lvl.size;
        filledUsd += lvlUsd;
        remainingUsd -= lvlUsd;
        consumedLevels++;
      }
    }

    const avgFillPrice = filledBase > 0 ? filledUsd / filledBase : midPrice;
    const slippageBps =
      midPrice > 0
        ? Math.round(
            ((avgFillPrice - midPrice) / midPrice) *
              (input.side === "buy" ? 10_000 : -10_000),
          )
        : 0;

    return {
      symbol: input.symbol,
      side: input.side,
      requestedUsd: input.sizeUsd,
      filledUsd: Math.round(filledUsd * 100) / 100,
      avgFillPrice,
      midPrice,
      slippageBps,
      filledBase,
      consumedLevels,
      fullyFilled: remainingUsd === 0,
    };
  }

  /**
   * Place a real order. Requires apiKey + apiSecret + passphrase.
   * In the dashboard demo we do NOT execute real orders — this is a stub
   * that documents the contract for production use.
   */
  async placeOrder(opts: {
    symbol: string;
    side: "buy" | "sell";
    orderType: "limit" | "market";
    size: number;
    price?: number;
    productType?: ProductType;
    reduceOnly?: boolean;
    timeInForce?: "GTC" | "IOC" | "FOK" | "POST_ONLY";
  }): Promise<{ orderId: string; status: string }> {
    if (!this.config.apiKey || !this.config.apiSecret || !this.config.passphrase) {
      throw new Error(
        "placeOrder requires apiKey, apiSecret, and passphrase. Configure them via SdkConfig or env vars.",
      );
    }
    // Production implementation would:
    // 1. Build the request body
    // 2. Sign with HMAC-SHA256 using apiSecret + timestamp
    // 3. POST to /api/v2/mix/order/place-order
    // For safety in the demo, we return a simulated orderId.
    throw new Error(
      "Live order placement is disabled in the demo build. Use simulateOrder() for pre-trade analysis.",
    );
  }
}
