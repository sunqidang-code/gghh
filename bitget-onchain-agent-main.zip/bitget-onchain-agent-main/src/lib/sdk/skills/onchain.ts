/**
 * On-Chain Skill
 *
 * Provides whale alerts, mempool monitoring, large exchange transfers, and
 * on-chain metrics. In production this would call the Skill Hub / a chain
 * indexer (e.g. Whale Alert API, Arkham, Nansen). For the dashboard demo
 * we generate deterministic realistic data so the UI is fully functional
 * without external credentials.
 */

import type { SkillHubAdapter } from "./skill-hub";
import type {
  ChainId,
  LargeTransfer,
  MempoolTx,
  OnChainMetric,
  SdkConfig,
  WhaleAlert,
} from "../types";

type ResolvedConfig = Pick<SdkConfig, "logger">;

const CHAIN_ASSETS: Record<ChainId, string[]> = {
  ethereum: ["ETH", "USDT", "USDC", "WETH", "WBTC"],
  solana: ["SOL", "USDC", "JUP", "WIF", "BONK"],
  bitcoin: ["BTC"],
  base: ["ETH", "USDC", "DEGEN"],
  arbitrum: ["ARB", "ETH", "USDC"],
  bsc: ["BNB", "USDT", "CAKE"],
};

const EXCHANGES = ["Binance", "Bitget", "OKX", "Bybit", "Coinbase", "Kraken"];

function pseudoRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

function shortAddr(chain: ChainId, rng: () => number): string {
  const chars = "0123456789abcdef";
  const len = chain === "solana" ? 44 : 42;
  let addr = chain === "solana" ? "" : "0x";
  for (let i = addr.length; i < len; i++) {
    addr += chars[Math.floor(rng() * chars.length)];
  }
  return addr;
}

export class OnChainSkill {
  constructor(
    private readonly skillHub: SkillHubAdapter,
    private readonly config: ResolvedConfig,
  ) {}

  /** Get recent whale alerts (large transfers) for a chain. */
  async getWhaleAlerts(opts: {
    chain?: ChainId;
    minUsd?: number;
    limit?: number;
    lookbackMs?: number;
  } = {}): Promise<WhaleAlert[]> {
    const { chain, minUsd = 100_000, limit = 20, lookbackMs = 3_600_000 } = opts;
    const now = Date.now();
    const rng = pseudoRandom(Math.floor(now / 60_000));

    const chains: ChainId[] = chain ? [chain] : ["ethereum", "solana", "bitcoin"];
    const alerts: WhaleAlert[] = [];

    for (let i = 0; i < limit; i++) {
      const c = chains[Math.floor(rng() * chains.length)];
      const assets = CHAIN_ASSETS[c];
      const asset = assets[Math.floor(rng() * assets.length)];
      const amountUsd = Math.round((minUsd + rng() * 9_900_000) * 100) / 100;
      const price = asset === "BTC" ? 67_000 : asset === "ETH" ? 3_500 : asset === "SOL" ? 145 : 1;
      const amount = amountUsd / price;
      const severity = amountUsd > 5_000_000 ? "critical" : amountUsd > 1_000_000 ? "warning" : "info";

      alerts.push({
        id: `whale_${now}_${i}`,
        chain: c,
        asset,
        amount,
        amountUsd,
        valueUsd: amountUsd,
        from: shortAddr(c, rng),
        to: shortAddr(c, rng),
        fromType: rng() > 0.6 ? "exchange" : rng() > 0.3 ? "wallet" : "unknown",
        toType: rng() > 0.6 ? "exchange" : rng() > 0.3 ? "wallet" : "unknown",
        fromLabel: rng() > 0.6 ? EXCHANGES[Math.floor(rng() * EXCHANGES.length)] : undefined,
        toLabel: rng() > 0.6 ? EXCHANGES[Math.floor(rng() * EXCHANGES.length)] : undefined,
        txHash: "0x" + Math.floor(rng() * 1e16).toString(16).padStart(16, "0"),
        ts: now - Math.floor(rng() * lookbackMs),
        severity,
      });
    }

    return alerts.sort((a, b) => b.ts - a.ts);
  }

  /** Get large transfers to/from exchanges. */
  async getLargeExchangeTransfers(opts: {
    exchange?: string;
    minUsd?: number;
    limit?: number;
  } = {}): Promise<LargeTransfer[]> {
    const { exchange, minUsd = 500_000, limit = 15 } = opts;
    const whales = await this.getWhaleAlerts({ minUsd, limit });
    const rng = pseudoRandom(Date.now() / 30_000);

    return whales
      .filter((w) => w.fromLabel || w.toLabel)
      .map((w) => {
        const ex = exchange ?? w.toLabel ?? w.fromLabel ?? EXCHANGES[Math.floor(rng() * EXCHANGES.length)];
        const direction: LargeTransfer["direction"] =
          w.toLabel === ex ? "in" : w.fromLabel === ex ? "out" : "internal";
        return { ...w, direction, exchange: ex };
      });
  }

  /** Watch mempool for high-value pending transactions. */
  async getMempoolTxs(opts: {
    chain?: ChainId;
    minValueUsd?: number;
    limit?: number;
  } = {}): Promise<MempoolTx[]> {
    const { chain = "ethereum", minValueUsd = 50_000, limit = 25 } = opts;
    const rng = pseudoRandom(Math.floor(Date.now() / 10_000));
    const assets = CHAIN_ASSETS[chain];
    const txs: MempoolTx[] = [];

    for (let i = 0; i < limit; i++) {
      const asset = assets[Math.floor(rng() * assets.length)];
      const valueUsd = Math.round((minValueUsd + rng() * 2_000_000) * 100) / 100;
      const price = asset === "BTC" ? 67_000 : asset === "ETH" ? 3_500 : asset === "SOL" ? 145 : 1;
      const hash = "0x" + Math.floor(rng() * 1e16).toString(16).padStart(16, "0");
      txs.push({
        chain,
        hash,
        txHash: hash,
        from: shortAddr(chain, rng),
        to: shortAddr(chain, rng),
        value: valueUsd / price,
        valueUsd,
        gasPrice: chain === "solana" ? Math.round(rng() * 5000) : Math.round(rng() * 80 + 10),
        method: ["transfer", "swap", "approve", "deposit", "withdraw"][Math.floor(rng() * 5)],
        ts: Date.now() - Math.floor(rng() * 60_000),
        priority: valueUsd > 500_000 ? "high" : valueUsd > 200_000 ? "medium" : "low",
      });
    }

    return txs.sort((a, b) => b.ts - a.ts);
  }

  /** Get aggregate on-chain metrics per chain. */
  async getOnChainMetrics(chain?: ChainId): Promise<OnChainMetric[]> {
    const chains: ChainId[] = chain ? [chain] : ["ethereum", "solana", "bitcoin"];
    const rng = pseudoRandom(Math.floor(Date.now() / 300_000));
    const metrics: OnChainMetric[] = [];

    const metricNames = ["active_addresses", "tx_count", "stablecoin_inflow", "exchange_outflow", "gas_median"];

    for (const c of chains) {
      for (const m of metricNames) {
        const base = m === "active_addresses" ? 200_000 : m === "tx_count" ? 1_200_000 : m === "stablecoin_inflow" ? 80_000_000 : m === "exchange_outflow" ? 25_000_000 : 30;
        const value = Math.round(base * (0.7 + rng() * 0.6));
        metrics.push({
          chain: c,
          metric: m,
          value,
          changePct24h: Math.round((rng() * 40 - 20) * 100) / 100,
          ts: Date.now(),
        });
      }
    }

    return metrics;
  }
}
