/**
 * Market Data Skill
 *
 * Wraps Bitget REST endpoints into a clean, typed interface. All methods
 * return plain data (not SdkResult) — use `BitgetOnChainAgent.wrap()` if
 * you need an error envelope.
 */

import type { BitgetRestClient } from "../../bitget/rest";
import type {
  Candle,
  CandleInterval,
  OrderBook,
  ProductType,
  SdkConfig,
  Ticker,
  Trade,
} from "../types";

type ResolvedConfig = Required<
  Pick<SdkConfig, "productType" | "telemetry">
> & Pick<SdkConfig, "logger">;

export class MarketDataSkill {
  constructor(
    private readonly rest: BitgetRestClient,
    private readonly config: ResolvedConfig,
  ) {}

  /** Get a single ticker (auto-detect spot vs futures by productType). */
  async getTicker(
    symbol: string,
    productType: ProductType = this.config.productType,
  ): Promise<Ticker> {
    if (productType === "SPOT") {
      return this.rest.getSpotTicker(symbol);
    }
    return this.rest.getFuturesTicker(symbol, productType);
  }

  /** Get all tickers for a product type. */
  async getTickers(productType: ProductType = this.config.productType): Promise<Ticker[]> {
    if (productType === "SPOT") {
      return this.rest.getSpotTickers();
    }
    return this.rest.getFuturesTickers(productType);
  }

  /** Get OHLCV candles. */
  async getCandles(
    symbol: string,
    granularity: CandleInterval = "1h",
    limit = 200,
    productType: ProductType = this.config.productType,
  ): Promise<Candle[]> {
    if (productType === "SPOT") {
      return this.rest.getSpotCandles(symbol, granularity, limit);
    }
    return this.rest.getFuturesCandles(symbol, granularity, limit, productType);
  }

  /** Get order book. */
  async getOrderBook(
    symbol: string,
    productType: ProductType = this.config.productType,
    precision = "0.1",
    limit = 50,
  ): Promise<OrderBook> {
    return this.rest.getOrderBook(symbol, productType, precision, limit);
  }

  /** Get recent trades. */
  async getRecentTrades(
    symbol: string,
    limit = 50,
    productType: ProductType = this.config.productType,
  ): Promise<Trade[]> {
    return this.rest.getRecentTrades(symbol, limit, productType);
  }

  /** Compute simple moving average over the last N closes. */
  async getSMA(
    symbol: string,
    period: number,
    granularity: CandleInterval = "1h",
    productType: ProductType = this.config.productType,
  ): Promise<number> {
    const candles = await this.getCandles(symbol, granularity, period, productType);
    const closes = candles.slice(-period).map((c) => c.close);
    if (closes.length === 0) return 0;
    return closes.reduce((a, b) => a + b, 0) / closes.length;
  }

  /** Compute RSI(14) over the last ~20 candles. */
  async getRSI(
    symbol: string,
    period = 14,
    granularity: CandleInterval = "1h",
    productType: ProductType = this.config.productType,
  ): Promise<number> {
    const candles = await this.getCandles(symbol, granularity, period + 20, productType);
    const closes = candles.map((c) => c.close);
    if (closes.length < period + 1) return 50;

    let gains = 0;
    let losses = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff >= 0) gains += diff;
      else losses -= diff;
    }
    const avgGain = gains / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - 100 / (1 + rs);
  }
}
