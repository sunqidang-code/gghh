/**
 * Risk Skill
 *
 * Pre-trade risk checks, position sizing, and exposure limits.
 * Pure functions — no network calls — so they're fast and deterministic.
 */

import type { RiskCheck, RiskCheckResult, SdkConfig } from "../types";

type ResolvedConfig = Pick<SdkConfig, "logger">;

export interface RiskCheckInput {
  symbol: string;
  sizeUsd: number;
  leverage: number;
  accountEquityUsd?: number;
  currentExposureUsd?: number;
  maxExposureUsd?: number;
  maxLeverage?: number;
  maxSinglePositionPct?: number; // % of equity, 0..1
  correlationScore?: number; // 0..1, correlation with existing book
  fundingRatePct?: number; // current funding rate as percent (e.g. 0.01 = 0.01%)
  volatilityPct?: number; // 24h realized vol as percent
}

const DEFAULTS = {
  maxLeverage: 20,
  maxSinglePositionPct: 0.25,
  maxExposureUsd: 100_000,
  maxFundingRatePct: 0.05, // 0.05% per 8h
  maxVolatilityPct: 8, // 8% daily
  maxCorrelation: 0.7,
};

export class RiskSkill {
  constructor(private readonly config: ResolvedConfig) {}

  /** Run all pre-trade risk checks. Returns aggregate pass/fail + score. */
  async checkPosition(input: RiskCheckInput): Promise<RiskCheckResult> {
    const checks: RiskCheck[] = [];
    const warnings: string[] = [];

    const equity = input.accountEquityUsd ?? 50_000;
    const maxLev = input.maxLeverage ?? DEFAULTS.maxLeverage;
    const maxPosPct = input.maxSinglePositionPct ?? DEFAULTS.maxSinglePositionPct;
    const maxExp = input.maxExposureUsd ?? DEFAULTS.maxExposureUsd;

    // 1. Leverage check
    const levOk = input.leverage <= maxLev;
    checks.push({
      name: "Leverage Limit",
      passed: levOk,
      detail: `${input.leverage}x vs max ${maxLev}x`,
      severity: levOk ? "info" : "critical",
    });
    if (!levOk) warnings.push(`Leverage ${input.leverage}x exceeds max ${maxLev}x`);

    // 2. Single position size check
    const posPct = input.sizeUsd / equity;
    const posOk = posPct <= maxPosPct;
    checks.push({
      name: "Single Position Size",
      passed: posOk,
      detail: `${(posPct * 100).toFixed(1)}% of equity vs max ${(maxPosPct * 100).toFixed(0)}%`,
      severity: posOk ? "info" : "warning",
    });
    if (!posOk) warnings.push(`Position size ${(posPct * 100).toFixed(1)}% exceeds ${(maxPosPct * 100).toFixed(0)}% limit`);

    // 3. Total exposure check
    const newExposure = (input.currentExposureUsd ?? 0) + input.sizeUsd * input.leverage;
    const expOk = newExposure <= maxExp;
    checks.push({
      name: "Total Exposure",
      passed: expOk,
      detail: `$${newExposure.toLocaleString()} vs max $${maxExp.toLocaleString()}`,
      severity: expOk ? "info" : "critical",
    });
    if (!expOk) warnings.push(`Total exposure $${newExposure.toLocaleString()} exceeds $${maxExp.toLocaleString()}`);

    // 4. Funding rate check (derivatives only)
    if (input.fundingRatePct !== undefined) {
      const fundOk = Math.abs(input.fundingRatePct) <= DEFAULTS.maxFundingRatePct;
      checks.push({
        name: "Funding Rate",
        passed: fundOk,
        detail: `${input.fundingRatePct.toFixed(4)}% vs max ±${DEFAULTS.maxFundingRatePct}%`,
        severity: fundOk ? "info" : "warning",
      });
      if (!fundOk) warnings.push(`Funding rate ${input.fundingRatePct.toFixed(4)}% is extreme — high carry cost`);
    }

    // 5. Volatility check
    if (input.volatilityPct !== undefined) {
      const volOk = input.volatilityPct <= DEFAULTS.maxVolatilityPct;
      checks.push({
        name: "Volatility",
        passed: volOk,
        detail: `${input.volatilityPct.toFixed(2)}% 24h vs max ${DEFAULTS.maxVolatilityPct}%`,
        severity: volOk ? "info" : "warning",
      });
      if (!volOk) warnings.push(`Volatility ${input.volatilityPct.toFixed(2)}% is elevated — reduce size`);
    }

    // 6. Correlation check
    if (input.correlationScore !== undefined) {
      const corrOk = input.correlationScore <= DEFAULTS.maxCorrelation;
      checks.push({
        name: "Correlation",
        passed: corrOk,
        detail: `${(input.correlationScore * 100).toFixed(0)}% vs max ${(DEFAULTS.maxCorrelation * 100).toFixed(0)}%`,
        severity: corrOk ? "info" : "warning",
      });
      if (!corrOk) warnings.push(`Correlation ${(input.correlationScore * 100).toFixed(0)}% with existing book — diversification risk`);
    }

    const passed = checks.every((c) => c.passed);
    const score = Math.round(
      (checks.filter((c) => c.passed).length / checks.length) * 100,
    );

    return { passed, score, checks, warnings };
  }

  /**
   * Kelly criterion position sizing.
   * Returns the fraction of equity to risk (0..1).
   */
  kellySize(winRate: number, winLossRatio: number): number {
    // f* = (p * b - q) / b
    // p = winRate, q = 1 - p, b = winLossRatio
    const p = winRate;
    const q = 1 - p;
    const b = winLossRatio;
    const f = (p * b - q) / b;
    // Use half-Kelly for safety
    return Math.max(0, Math.min(0.25, f / 2));
  }

  /**
   * Compute stop-loss price given entry, side, and stop pct.
   */
  computeStopLoss(entry: number, side: "long" | "short", stopPct: number): number {
    return side === "long"
      ? entry * (1 - stopPct)
      : entry * (1 + stopPct);
  }

  /**
   * Compute take-profit price given entry, side, and tp pct.
   */
  computeTakeProfit(entry: number, side: "long" | "short", tpPct: number): number {
    return side === "long"
      ? entry * (1 + tpPct)
      : entry * (1 - tpPct);
  }
}
