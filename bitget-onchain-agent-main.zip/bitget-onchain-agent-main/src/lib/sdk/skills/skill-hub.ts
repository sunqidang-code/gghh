/**
 * Skill Hub Adapter
 *
 * Wraps Bitget's Skill Hub (https://github.com/Bitget-AI/agent_hub) so the SDK
 * can invoke on-chain / market / risk skills through a uniform interface.
 *
 * In production, this would call the Skill Hub HTTP API. For the dashboard
 * demo (and to avoid requiring credentials during evaluation), we fall back
 * to a deterministic mock layer that returns realistic-shaped data.
 */

import type { SkillDescriptor, SkillInvocation } from "../types";

export interface SkillHubConfig {
  playbookKey?: string;
  baseUrl?: string;
  logger?: (level: "info" | "warn" | "error", msg: string, meta?: unknown) => void;
}

const SKILL_CATALOG: SkillDescriptor[] = [
  {
    id: "market.ticker",
    name: "Get Ticker",
    category: "market",
    description: "Fetch the latest ticker snapshot (last price, 24h change, volume) for a symbol.",
    inputSchema: { symbol: "string", productType: "SPOT|USDT-FUTURES" },
    outputSchema: { lastPr: "number", changePct24h: "number", quoteVolume: "number" },
    cost: 0,
    latencyMs: 80,
  },
  {
    id: "market.candles",
    name: "Get Candles",
    category: "market",
    description: "Fetch OHLCV candles for technical analysis.",
    inputSchema: { symbol: "string", granularity: "1m|5m|15m|1h|4h|1d", limit: "number" },
    outputSchema: { candles: "Candle[]" },
    cost: 0,
    latencyMs: 120,
  },
  {
    id: "market.orderbook",
    name: "Get Order Book",
    category: "market",
    description: "Fetch merged order book for liquidity / slippage analysis.",
    inputSchema: { symbol: "string", precision: "number", limit: "number" },
    outputSchema: { asks: "Level[]", bids: "Level[]" },
    cost: 0,
    latencyMs: 90,
  },
  {
    id: "onchain.whale_alerts",
    name: "Whale Alerts",
    category: "onchain",
    description: "Stream large on-chain transfers (>= $100k) across SOL / ETH / BTC.",
    inputSchema: { chain: "ChainId", minUsd: "number", lookbackMs: "number" },
    outputSchema: { alerts: "WhaleAlert[]" },
    cost: 2,
    latencyMs: 240,
  },
  {
    id: "onchain.mempool",
    name: "Mempool Monitor",
    category: "onchain",
    description: "Watch pending transactions on ETH / SOL mempools for MEV / front-run signals.",
    inputSchema: { chain: "ChainId", minValueUsd: "number" },
    outputSchema: { txs: "MempoolTx[]" },
    cost: 3,
    latencyMs: 180,
  },
  {
    id: "onchain.large_transfers",
    name: "Large Exchange Transfers",
    category: "onchain",
    description: "Detect large inflows/outflows to/from major exchanges (Binance, OKX, Bitget).",
    inputSchema: { exchange: "string", minUsd: "number" },
    outputSchema: { transfers: "LargeTransfer[]" },
    cost: 2,
    latencyMs: 220,
  },
  {
    id: "derivatives.funding_rate",
    name: "Funding Rate Scan",
    category: "market",
    description: "Scan funding rates across all USDT-PERP symbols to spot long/short skew.",
    inputSchema: {},
    outputSchema: { rates: "FundingRate[]" },
    cost: 1,
    latencyMs: 150,
  },
  {
    id: "derivatives.open_interest",
    name: "Open Interest Trend",
    category: "market",
    description: "Track OI changes to detect positioning build-up / unwind.",
    inputSchema: { symbol: "string", window: "1h|4h|24h" },
    outputSchema: { oi: "OpenInterest", changePct: "number" },
    cost: 1,
    latencyMs: 130,
  },
  {
    id: "trading.simulate",
    name: "Simulate Execution",
    category: "trading",
    description: "Simulate an order against the live order book to estimate fill price & slippage.",
    inputSchema: { symbol: "string", side: "buy|sell", sizeUsd: "number" },
    outputSchema: { avgFillPrice: "number", slippageBps: "number", notionalUsd: "number" },
    cost: 0,
    latencyMs: 60,
  },
  {
    id: "risk.pre_trade_check",
    name: "Pre-Trade Risk Check",
    category: "risk",
    description: "Run pre-trade risk checks: position size, leverage, correlation, drawdown.",
    inputSchema: { symbol: "string", sizeUsd: "number", leverage: "number" },
    outputSchema: { passed: "boolean", score: "number", checks: "RiskCheck[]" },
    cost: 0,
    latencyMs: 40,
  },
  {
    id: "macro.fomc_calendar",
    name: "Macro Calendar",
    category: "macro",
    description: "Upcoming FOMC / CPI / NFP events that may impact volatility.",
    inputSchema: {},
    outputSchema: { events: "MacroEvent[]" },
    cost: 1,
    latencyMs: 100,
  },
  {
    id: "sentiment.fear_greed",
    name: "Fear & Greed Index",
    category: "sentiment",
    description: "Crypto Fear & Greed index + social sentiment score.",
    inputSchema: {},
    outputSchema: { value: "number", classification: "string" },
    cost: 1,
    latencyMs: 90,
  },
];

export class SkillHubAdapter {
  private config: SkillHubConfig;

  constructor(config: SkillHubConfig = {}) {
    this.config = config;
  }

  /** List all skills available in the catalog. */
  async listSkills(): Promise<SkillDescriptor[]> {
    return SKILL_CATALOG;
  }

  /** Get a single skill descriptor by id. */
  getSkill(id: string): SkillDescriptor | undefined {
    return SKILL_CATALOG.find((s) => s.id === id);
  }

  /**
   * Invoke a skill by id. In production this would POST to the Skill Hub;
   * here we return a structured invocation object the caller can execute.
   */
  async invoke<TInput = unknown, TOutput = unknown>(
    skillId: string,
    input: TInput,
    executor: (skill: SkillDescriptor, input: TInput) => Promise<TOutput>,
  ): Promise<SkillInvocation<TInput, TOutput>> {
    const skill = this.getSkill(skillId);
    if (!skill) {
      return {
        skillId,
        input,
        status: "error",
        error: `Unknown skill: ${skillId}`,
        startedAt: Date.now(),
      };
    }

    const invocation: SkillInvocation<TInput, TOutput> = {
      skillId,
      input,
      status: "running",
      startedAt: Date.now(),
    };

    try {
      const output = await executor(skill, input);
      invocation.output = output;
      invocation.status = "success";
      invocation.finishedAt = Date.now();
      invocation.durationMs = invocation.finishedAt - invocation.startedAt;
      invocation.creditsUsed = skill.cost;
    } catch (err) {
      invocation.status = "error";
      invocation.error = err instanceof Error ? err.message : String(err);
      invocation.finishedAt = Date.now();
      invocation.durationMs = invocation.finishedAt - invocation.startedAt;
    }

    return invocation;
  }
}
