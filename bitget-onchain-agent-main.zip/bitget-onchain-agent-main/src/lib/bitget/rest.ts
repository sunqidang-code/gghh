/**
 * Bitget REST API client — thin wrapper around Bitget v2 public endpoints.
 *
 * Docs: https://www.bitget.com/api-doc/common/intro
 *
 * This client is intentionally framework-agnostic (uses `fetch`) so it can run
 * in Node, Bun, Edge runtimes, and the browser. Authenticated endpoints are
 * supported but not required for the public market / on-chain data used by
 * the Monitor dashboard.
 */

import type {
  Candle,
  CandleInterval,
  FundingRate,
  MarkPrice,
  OpenInterest,
  OrderBook,
  ProductType,
  SdkConfig,
  SymbolInfo,
  Ticker,
  Trade,
} from "../sdk/types";

const DEFAULT_BASE_URL = "https://api.bitget.com";
const DEFAULT_TIMEOUT = 12_000;

export interface BitgetRestOptions {
  baseUrl?: string;
  timeout?: number;
  fetchImpl?: typeof fetch;
}

export class BitgetRestClient {
  private baseUrl: string;
  private timeout: number;
  private fetchImpl: typeof fetch;

  constructor(opts: BitgetRestOptions = {}) {
    this.baseUrl = (opts.baseUrl ?? DEFAULT_BASE_URL).replace(/\/$/, "");
    this.timeout = opts.timeout ?? DEFAULT_TIMEOUT;
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  static fromSdkConfig(config: SdkConfig): BitgetRestClient {
    return new BitgetRestClient({
      baseUrl: config.baseUrl,
      timeout: config.timeout,
      fetchImpl: config.fetchImpl,
    });
  }

  private async request<T>(
    path: string,
    params: Record<string, string | number | boolean | undefined> = {},
  ): Promise<T> {
    const url = new URL(this.baseUrl + path);
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== "") {
        url.searchParams.set(k, String(v));
      }
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeout);

    try {
      const res = await this.fetchImpl(url.toString(), {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "bitget-onchain-agent-sdk/1.0",
        },
        signal: controller.signal,
      });

      if (!res.ok) {
        const body = await res.text().catch(() => "");
        throw new Error(
          `Bitget API ${res.status}: ${body || res.statusText} (${url.pathname})`,
        );
      }

      const json = (await res.json()) as {
        code: string;
        msg: string;
        data: T;
      };

      if (json.code !== "00000") {
        throw new Error(`Bitget API error ${json.code}: ${json.msg}`);
      }

      return json.data;
    } finally {
      clearTimeout(timer);
    }
  }

  /* ---------------------------------------------------------------- */
  /* Public market data                                               */
  /* ---------------------------------------------------------------- */

  /** GET /api/v2/spot/public/symbols — list spot symbols */
  async getSpotSymbols(): Promise<SymbolInfo[]> {
    const data = await this.request<{ symbol: string; baseCoin: string; quoteCoin: string; minSize: string; maxSize: string; sizeIncrement: string; priceIncrement: string; status: string }[]>(
      "/api/v2/spot/public/symbols",
    );
    return data.map((d) => ({
      symbol: d.symbol,
      baseCoin: d.baseCoin,
      quoteCoin: d.quoteCoin,
      minSize: Number(d.minSize),
      maxSize: Number(d.maxSize),
      sizeIncrement: Number(d.sizeIncrement),
      priceIncrement: Number(d.priceIncrement),
      status: d.status as SymbolInfo["status"],
      productType: "SPOT",
    }));
  }

  /** GET /api/v2/mix/market/tickers — futures tickers */
  async getFuturesTickers(productType: ProductType = "USDT-FUTURES"): Promise<Ticker[]> {
    const data = await this.request<Array<Record<string, string>>>(
      "/api/v2/mix/market/tickers",
      { productType },
    );
    return data.map((d) => this.parseTicker(d));
  }

  /** GET /api/v2/spot/market/tickers — spot tickers */
  async getSpotTickers(): Promise<Ticker[]> {
    const data = await this.request<Array<Record<string, string>>>(
      "/api/v2/spot/market/tickers",
    );
    return data.map((d) => this.parseTicker(d));
  }

  /** GET /api/v2/spot/market/ticker?symbol=... */
  async getSpotTicker(symbol: string): Promise<Ticker> {
    const data = await this.request<Record<string, string>>(
      "/api/v2/spot/market/ticker",
      { symbol },
    );
    return this.parseTicker(data);
  }

  /** GET /api/v2/mix/market/ticker?symbol=...&productType=... */
  async getFuturesTicker(symbol: string, productType: ProductType = "USDT-FUTURES"): Promise<Ticker> {
    const data = await this.request<Record<string, string>>(
      "/api/v2/mix/market/ticker",
      { symbol, productType },
    );
    return this.parseTicker(data);
  }

  /** GET /api/v2/mix/market/candles — futures candles */
  async getFuturesCandles(
    symbol: string,
    granularity: CandleInterval = "1h",
    limit = 200,
    productType: ProductType = "USDT-FUTURES",
  ): Promise<Candle[]> {
    const data = await this.request<string[][]>(
      "/api/v2/mix/market/candles",
      { symbol, granularity, limit, productType },
    );
    return data.map((row) => this.parseCandle(row));
  }

  /** GET /api/v2/spot/market/candles — spot candles */
  async getSpotCandles(
    symbol: string,
    granularity: CandleInterval = "1h",
    limit = 200,
  ): Promise<Candle[]> {
    const data = await this.request<string[][]>(
      "/api/v2/spot/market/candles",
      { symbol, granularity, limit },
    );
    return data.map((row) => this.parseCandle(row));
  }

  /** GET /api/v2/mix/market/merge-depth — order book */
  async getOrderBook(
    symbol: string,
    productType: ProductType = "USDT-FUTURES",
    precision = "0.1",
    limit = 50,
  ): Promise<OrderBook> {
    const data = await this.request<{
      asks: string[][];
      bids: string[][];
      ts: string;
    }>("/api/v2/mix/market/merge-depth", { symbol, productType, precision, limit });

    return {
      symbol,
      asks: data.asks.map((r) => ({ price: Number(r[0]), size: Number(r[1]) })),
      bids: data.bids.map((r) => ({ price: Number(r[0]), size: Number(r[1]) })),
      ts: Number(data.ts),
    };
  }

  /** GET /api/v2/mix/market/fills — recent trades */
  async getRecentTrades(
    symbol: string,
    limit = 50,
    productType: ProductType = "USDT-FUTURES",
  ): Promise<Trade[]> {
    const data = await this.request<Array<Record<string, string>>>(
      "/api/v2/mix/market/fills",
      { symbol, limit, productType },
    );
    return data.map((d) => ({
      symbol,
      tradeId: d.tradeId ?? d.tId ?? "",
      price: Number(d.price),
      size: Number(d.size ?? d.baseVolume ?? "0"),
      side: d.side as "buy" | "sell",
      ts: Number(d.ts),
    }));
  }

  /* ---------------------------------------------------------------- */
  /* Derivatives                                                      */
  /* ---------------------------------------------------------------- */

  /** GET /api/v2/mix/market/current-fund-rate — current funding rate */
  async getFundingRate(
    symbol: string,
    productType: ProductType = "USDT-FUTURES",
  ): Promise<FundingRate> {
    const data = await this.request<Record<string, string>>(
      "/api/v2/mix/market/current-fund-rate",
      { symbol, productType },
    );
    return {
      symbol,
      fundingRate: Number(data.fundingRate),
      nextFundingTime: Number(data.nextFundingTime),
      fundingInterval: Number(data.fundingInterval ?? 8),
      ts: Date.now(),
    };
  }

  /** GET /api/v2/mix/market/open-interest — open interest */
  async getOpenInterest(
    symbol: string,
    productType: ProductType = "USDT-FUTURES",
  ): Promise<OpenInterest> {
    const data = await this.request<Record<string, string>>(
      "/api/v2/mix/market/open-interest",
      { symbol, productType },
    );
    return {
      symbol,
      openInterest: Number(data.amount ?? data.openInterest ?? "0"),
      openInterestUsd: Number(data.amountUsd ?? "0"),
      ts: Number(data.ts ?? Date.now()),
    };
  }

  /** GET /api/v2/mix/market/mark-price — mark price */
  async getMarkPrice(
    symbol: string,
    productType: ProductType = "USDT-FUTURES",
  ): Promise<MarkPrice> {
    const data = await this.request<Record<string, string>>(
      "/api/v2/mix/market/mark-price",
      { symbol, productType },
    );
    return {
      symbol,
      markPrice: Number(data.markPrice),
      indexPrice: Number(data.indexPrice),
      ts: Number(data.ts ?? Date.now()),
    };
  }

  /* ---------------------------------------------------------------- */
  /* Parsers                                                          */
  /* ---------------------------------------------------------------- */

  private parseTicker(d: Record<string, string>): Ticker {
    return {
      symbol: d.symbol ?? d.instId ?? "",
      lastPr: Number(d.lastPr ?? d.last ?? "0"),
      askPr: Number(d.askPr ?? d.askPx ?? "0"),
      bidPr: Number(d.bidPr ?? d.bidPx ?? "0"),
      bidSz: Number(d.bidSz ?? "0"),
      askSz: Number(d.askSz ?? "0"),
      high24h: Number(d.high24h ?? d.high24hStr ?? "0"),
      low24h: Number(d.low24h ?? d.low24hStr ?? "0"),
      change24h: Number(d.change24h ?? "0"),
      changePct24h: Number(d.changePct24h ?? d.priceChangePercent ?? "0"),
      baseVolume: Number(d.baseVolume ?? d.baseVolumeString ?? "0"),
      quoteVolume: Number(d.quoteVolume ?? d.quoteVolumeString ?? "0"),
      ts: Number(d.ts ?? Date.now()),
    };
  }

  private parseCandle(row: string[]): Candle {
    // Bitget returns: [ts, open, high, low, close, baseVol, quoteVol?]
    return {
      ts: Number(row[0]),
      open: Number(row[1]),
      high: Number(row[2]),
      low: Number(row[3]),
      close: Number(row[4]),
      volume: Number(row[5]),
      quoteVolume: row[6] ? Number(row[6]) : undefined,
    };
  }
}

/** Singleton instance for server-side use (no auth needed for public data). */
let _client: BitgetRestClient | null = null;
export function getBitgetClient(): BitgetRestClient {
  if (!_client) {
    _client = new BitgetRestClient();
  }
  return _client;
}
