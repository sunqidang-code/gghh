/**
 * Mock data generators for the dashboard demo.
 *
 * In production, the SDK calls Bitget's public API directly. For the
 * Hackathon demo we generate realistic-shaped data so the dashboard is
 * fully interactive without requiring API credentials or hitting rate
 * limits during evaluation.
 *
 * The generators are deterministic per-tick (seeded by minute / second)
 * so values are stable between re-renders but evolve over time.
 */

import type {
  AgentExecutionLog,
  AgentSignal,
  Alert,
  Candle,
  FundingRate,
  MempoolTx,
  OpenInterest,
  SignalSource,
  Ticker,
  WhaleAlert,
  ChainId,
} from "../sdk/types";

const BASE_PRICES: Record<string, number> = {
  BTCUSDT: 67_245.5,
  ETHUSDT: 3_512.8,
  SOLUSDT: 145.32,
  BNBUSDT: 612.45,
  XRPUSDT: 0.5234,
  DOGEUSDT: 0.1342,
  ADAUSDT: 0.4123,
  AVAXUSDT: 28.45,
  LINKUSDT: 14.23,
  TONUSDT: 7.45,
};

const SYMBOLS = Object.keys(BASE_PRICES);

function rng(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

function jitter(base: number, pct: number, r: number): number {
  return base * (1 + (r - 0.5) * 2 * pct);
}

export function generateMockTickers(symbols: string[] = SYMBOLS): Ticker[] {
  const seed = Math.floor(Date.now() / 3000);
  const r = rng(seed);

  return symbols.map((symbol) => {
    const base = BASE_PRICES[symbol] ?? 100;
    const lastPr = jitter(base, 0.015, r());
    const changePct24h = (r() - 0.45) * 12; // -5.4% .. +6.6%
    const change24h = lastPr * changePct24h / 100;
    const spread = lastPr * 0.0002;
    return {
      symbol,
      lastPr: Math.round(lastPr * 100) / 100,
      askPr: Math.round((lastPr + spread) * 100) / 100,
      bidPr: Math.round((lastPr - spread) * 100) / 100,
      bidSz: Math.round(r() * 10 * 100) / 100,
      askSz: Math.round(r() * 10 * 100) / 100,
      high24h: Math.round(jitter(lastPr, 0.025, 1) * 100) / 100,
      low24h: Math.round(jitter(lastPr, 0.025, 0) * 100) / 100,
      change24h: Math.round(change24h * 100) / 100,
      changePct24h: Math.round(changePct24h * 100) / 100,
      baseVolume: Math.round(r() * 50_000 * base),
      quoteVolume: Math.round(r() * 50_000 * base * lastPr),
      ts: Date.now(),
    };
  });
}

export function generateMockCandles(symbol: string, limit = 100): Candle[] {
  const base = BASE_PRICES[symbol] ?? 100;
  const now = Date.now();
  const hourMs = 3_600_000;
  const r = rng(Math.floor(now / 60_000));
  let price = base * (0.95 + r() * 0.1);
  const candles: Candle[] = [];

  for (let i = limit - 1; i >= 0; i--) {
    const ts = now - i * hourMs;
    const open = price;
    const volatility = base * 0.01;
    const close = open + (r() - 0.5) * volatility * 2;
    const high = Math.max(open, close) + r() * volatility;
    const low = Math.min(open, close) - r() * volatility;
    const volume = Math.round((r() * 5000 + 1000) * base);
    candles.push({
      ts,
      open: Math.round(open * 100) / 100,
      high: Math.round(high * 100) / 100,
      low: Math.round(low * 100) / 100,
      close: Math.round(close * 100) / 100,
      volume,
    });
    price = close;
  }

  return candles;
}

export function generateMockFundingRates(): FundingRate[] {
  const r = rng(Math.floor(Date.now() / 60_000));
  return SYMBOLS.slice(0, 8).map((symbol) => {
    const rate = (r() - 0.5) * 0.0008; // ±0.04%
    return {
      symbol,
      fundingRate: Math.round(rate * 1e8) / 1e8,
      nextFundingTime: Math.ceil(Date.now() / 8_640_000) * 8_640_000,
      fundingInterval: 8,
      ts: Date.now(),
    };
  });
}

export function generateMockOpenInterest(symbols: string[] = SYMBOLS.slice(0, 5)): OpenInterest[] {
  const r = rng(Math.floor(Date.now() / 60_000));
  return symbols.map((symbol) => {
    const base = BASE_PRICES[symbol] ?? 100;
    const oi = (r() * 100_000 + 20_000);
    return {
      symbol,
      openInterest: Math.round(oi),
      openInterestUsd: Math.round(oi * base),
      ts: Date.now(),
    };
  });
}

const CHAINS: ChainId[] = ["ethereum", "solana", "bitcoin"];
const ASSETS_BY_CHAIN: Record<ChainId, string[]> = {
  ethereum: ["ETH", "USDT", "USDC", "WBTC"],
  solana: ["SOL", "USDC", "JUP", "WIF"],
  bitcoin: ["BTC"],
  base: ["ETH", "USDC"],
  arbitrum: ["ARB", "ETH"],
  bsc: ["BNB", "USDT"],
};

function shortAddr(chain: ChainId, r: () => number): string {
  const chars = "0123456789abcdef";
  const len = chain === "solana" ? 44 : 42;
  let addr = chain === "solana" ? "" : "0x";
  for (let i = addr.length; i < len; i++) {
    addr += chars[Math.floor(r() * chars.length)];
  }
  return addr;
}

export function generateMockWhaleAlerts(limit = 20): WhaleAlert[] {
  const now = Date.now();
  const r = rng(Math.floor(now / 10_000));
  const alerts: WhaleAlert[] = [];

  for (let i = 0; i < limit; i++) {
    const chain = CHAINS[Math.floor(r() * CHAINS.length)];
    const assets = ASSETS_BY_CHAIN[chain];
    const asset = assets[Math.floor(r() * assets.length)];
    const amountUsd = Math.round((100_000 + r() * 9_900_000) * 100) / 100;
    const price = asset === "BTC" ? 67_000 : asset === "ETH" ? 3_500 : asset === "SOL" ? 145 : 1;
    const amount = amountUsd / price;
    const severity = amountUsd > 5_000_000 ? "critical" : amountUsd > 1_000_000 ? "warning" : "info";

    alerts.push({
      id: `whale_${now}_${i}`,
      chain,
      asset,
      amount,
      amountUsd,
      valueUsd: amountUsd,
      from: shortAddr(chain, r),
      to: shortAddr(chain, r),
      fromType: r() > 0.6 ? "exchange" : r() > 0.3 ? "wallet" : "unknown",
      toType: r() > 0.6 ? "exchange" : r() > 0.3 ? "wallet" : "unknown",
      fromLabel: r() > 0.6 ? "Binance" : r() > 0.3 ? "Bitget" : undefined,
      toLabel: r() > 0.6 ? "OKX" : r() > 0.3 ? "Cold Wallet" : undefined,
      txHash: "0x" + Math.floor(r() * 1e16).toString(16).padStart(16, "0"),
      ts: now - Math.floor(r() * 3_600_000),
      severity,
    });
  }

  return alerts.sort((a, b) => b.ts - a.ts);
}

export function generateMockAlerts(): Alert[] {
  const now = Date.now();
  const r = rng(Math.floor(now / 30_000));
  const templates: Array<Omit<Alert, "id" | "ts" | "acknowledged">> = [
    {
      category: "whale",
      severity: "critical",
      title: "Whale Transfer Detected",
      message: "1,250 BTC ($83.9M) moved from Binance to cold wallet",
      symbol: "BTCUSDT",
      chain: "bitcoin",
      value: 83_900_000,
      threshold: 5_000_000,
    },
    {
      category: "funding",
      severity: "warning",
      title: "Extreme Funding Rate",
      message: "SOLUSDT funding rate hit 0.0482% — longs paying shorts heavily",
      symbol: "SOLUSDT",
      value: 0.0482,
      threshold: 0.05,
    },
    {
      category: "open_interest",
      severity: "warning",
      title: "OI Surge",
      message: "ETHUSDT OI up 18.4% in 4h — potential squeeze setup",
      symbol: "ETHUSDT",
      value: 18.4,
      threshold: 15,
    },
    {
      category: "volume",
      severity: "info",
      title: "Volume Spike",
      message: "DOGEUSDT 1h volume 3.2x above 24h average",
      symbol: "DOGEUSDT",
      value: 3.2,
      threshold: 2.5,
    },
    {
      category: "agent",
      severity: "info",
      title: "Agent Signal",
      message: "MomentumAgent-7 opened LONG BTCUSDT @ $67,180 (5x leverage)",
      symbol: "BTCUSDT",
      value: 0.78,
      threshold: 0.7,
    },
    {
      category: "liquidation",
      severity: "critical",
      title: "Liquidation Cascade",
      message: "$12.4M in ETH longs liquidated in 5min window",
      symbol: "ETHUSDT",
      value: 12_400_000,
      threshold: 10_000_000,
    },
    {
      category: "whale",
      severity: "warning",
      title: "Exchange Inflow",
      message: "4.2M USDC deposited to Bitget from unknown wallet",
      chain: "ethereum",
      value: 4_200_000,
      threshold: 1_000_000,
    },
  ];

  return templates
    .map((t, i) => ({
      ...t,
      id: `alert_${now}_${i}`,
      ts: now - Math.floor(r() * 1_800_000),
      acknowledged: false,
    }))
    .sort((a, b) => b.ts - a.ts);
}

const AGENT_NAMES = [
  "MomentumAgent-7",
  "MeanReversion-Bot",
  "FundingArb-Agent",
  "WhaleShadow-AI",
  "SentimentTrader",
  "BreakoutHunter",
];

export function generateMockAgentSignals(): AgentSignal[] {
  const now = Date.now();
  const r = rng(Math.floor(now / 30_000));
  const symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "AVAXUSDT", "LINKUSDT"];

  return AGENT_NAMES.map((name, i) => {
    const symbol = symbols[i % symbols.length];
    const side = (["long", "short", "neutral"] as const)[Math.floor(r() * 3)];
    const confidence = Math.round((0.4 + r() * 0.55) * 100) / 100;
    const riskScore = Math.round(r() * 70 + 20);

    const sources: SignalSource[] = [];
    if (r() > 0.3) sources.push({ type: "onchain", label: "Whale inflow to exchange", weight: 0.3, value: "+$8.2M" });
    if (r() > 0.4) sources.push({ type: "technical", label: "RSI(14) oversold", weight: 0.25, value: "28.4" });
    if (r() > 0.5) sources.push({ type: "funding", label: "Negative funding", weight: 0.2, value: "-0.012%" });
    if (r() > 0.6) sources.push({ type: "sentiment", label: "Fear & Greed", weight: 0.15, value: "32 (Fear)" });
    if (r() > 0.7) sources.push({ type: "orderflow", label: "Bid-ask imbalance", weight: 0.1, value: "+0.18" });

    return {
      id: `signal_${now}_${i}`,
      agentId: `agent_${i}`,
      agentName: name,
      symbol,
      side,
      confidence,
      reasoning: `${side === "long" ? "Bullish" : side === "short" ? "Bearish" : "Neutral"} setup detected via ${sources.length} signals. ${sources[0]?.label ?? "Composite signal"} is the primary driver.`,
      suggestedAction: side === "neutral" ? "Hold / observe" : `Open ${side.toUpperCase()} with ${Math.round(confidence * 100)}% confidence, size 2% of equity`,
      riskScore,
      ts: now - Math.floor(r() * 600_000),
      sources,
    };
  });
}

export function generateMockAgentLogs(): AgentExecutionLog[] {
  const now = Date.now();
  const r = rng(Math.floor(now / 20_000));
  const symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "AVAXUSDT", "LINKUSDT"];
  const actions = ["OPEN_LONG", "OPEN_SHORT", "CLOSE_LONG", "CLOSE_SHORT", "ADJUST_LEVERAGE", "CANCEL_ORDER"];
  const logs: AgentExecutionLog[] = [];

  for (let i = 0; i < 25; i++) {
    const agentName = AGENT_NAMES[Math.floor(r() * AGENT_NAMES.length)];
    const action = actions[Math.floor(r() * actions.length)];
    const symbol = symbols[Math.floor(r() * symbols.length)];
    const success = r() > 0.15;
    const pnlUsd = success ? Math.round((r() - 0.4) * 5000) : 0;

    logs.push({
      id: `log_${now}_${i}`,
      agentId: `agent_${Math.floor(r() * AGENT_NAMES.length)}`,
      agentName,
      action,
      symbol,
      status: success ? "success" : "failed",
      pnlUsd,
      durationMs: Math.round(r() * 800 + 50),
      ts: now - Math.floor(r() * 3_600_000),
      message: success
        ? `${action} ${symbol} executed — PnL $${pnlUsd}`
        : `${action} ${symbol} failed — slippage exceeded threshold`,
    });
  }

  return logs.sort((a, b) => b.ts - a.ts);
}

export function generateMockMempool(chain: ChainId = "ethereum", limit = 15): MempoolTx[] {
  const now = Date.now();
  const r = rng(Math.floor(now / 3000));
  const assets = chain === "solana" ? ["SOL", "USDC", "JUP"] : chain === "bitcoin" ? ["BTC"] : ["ETH", "USDT", "USDC", "WBTC"];
  const methods = ["transfer", "swap", "approve", "deposit", "withdraw", "multicall"];
  const txs: MempoolTx[] = [];

  for (let i = 0; i < limit; i++) {
    const asset = assets[Math.floor(r() * assets.length)];
    const price = asset === "BTC" ? 67000 : asset === "ETH" || asset === "WETH" || asset === "WBTC" ? 3500 : 1;
    const valueUsd = Math.round(r() * 2_000_000 + 10_000);
    const value = valueUsd / price;
    const hash = "0x" + Math.floor(r() * 1e16).toString(16).padStart(16, "0");

    txs.push({
      chain,
      hash,
      txHash: hash,
      from: shortAddr(chain, r),
      to: shortAddr(chain, r),
      value,
      valueUsd,
      gasPrice: chain === "solana" ? Math.round(r() * 5000) : Math.round(r() * 80 + 10),
      method: methods[Math.floor(r() * methods.length)],
      ts: now - Math.floor(r() * 60_000),
      priority: valueUsd > 500_000 ? "high" : valueUsd > 200_000 ? "medium" : "low",
    });
  }

  return txs.sort((a, b) => b.ts - a.ts);
}
