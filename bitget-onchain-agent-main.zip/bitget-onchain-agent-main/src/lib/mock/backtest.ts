/**
 * Mock backtest engine.
 *
 * Generates a realistic backtest result for a given strategy config.
 * In production this would replay historical candles through the strategy
 * logic; for the demo we synthesize trades and metrics that look plausible.
 */

import type {
  BacktestConfig,
  BacktestMetrics,
  BacktestResult,
  BacktestTrade,
  Candle,
} from "../sdk/types";
import { generateMockCandles } from "./data";

export interface MockBacktestInput {
  symbol: string;
  strategy: "momentum" | "mean_reversion" | "funding_arb" | "whale_follow";
  interval: BacktestConfig["interval"];
  days: number;
  initialCapital: number;
  positionSizePct: number;
  stopLossPct: number;
  takeProfitPct: number;
  maxLeverage: number;
}

function rng(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

export function runMockBacktest(input: MockBacktestInput): BacktestResult {
  const r = rng(Date.now() % 1_000_000);
  const limit = Math.min(input.days * 24, 2000);
  const candles: Candle[] = generateMockCandles(input.symbol, limit);

  const trades: BacktestTrade[] = [];
  let equity = input.initialCapital;
  const equityCurve: { ts: number; equity: number; drawdown: number }[] = [];
  let peakEquity = equity;

  // Generate trades based on strategy
  const tradeCount = Math.floor(input.days * (1 + r() * 2));
  const intervalMs = 3_600_000;

  for (let i = 0; i < tradeCount; i++) {
    const entryIdx = Math.floor((i / tradeCount) * (candles.length - 10)) + 1;
    const entryCandle = candles[entryIdx];
    if (!entryCandle) continue;

    const side: "long" | "short" = r() > 0.5 ? "long" : "short";
    const entryPrice = entryCandle.close;
    const holdBars = Math.floor(r() * 12 + 2);
    const exitIdx = Math.min(entryIdx + holdBars, candles.length - 1);
    const exitCandle = candles[exitIdx];
    if (!exitCandle) continue;

    // Decide exit reason
    const tpPrice =
      side === "long"
        ? entryPrice * (1 + input.takeProfitPct)
        : entryPrice * (1 - input.takeProfitPct);
    const slPrice =
      side === "long"
        ? entryPrice * (1 - input.stopLossPct)
        : entryPrice * (1 + input.stopLossPct);

    let exitPrice = exitCandle.close;
    let reason: BacktestTrade["reason"] = "signal_exit";

    // Check if TP or SL hit during holding period
    for (let j = entryIdx + 1; j <= exitIdx; j++) {
      const c = candles[j];
      if (!c) break;
      if (side === "long") {
        if (c.high >= tpPrice) {
          exitPrice = tpPrice;
          reason = "take_profit";
          break;
        }
        if (c.low <= slPrice) {
          exitPrice = slPrice;
          reason = "stop_loss";
          break;
        }
      } else {
        if (c.low <= tpPrice) {
          exitPrice = tpPrice;
          reason = "take_profit";
          break;
        }
        if (c.high >= slPrice) {
          exitPrice = slPrice;
          reason = "stop_loss";
          break;
        }
      }
    }

    const size = (equity * input.positionSizePct * input.maxLeverage) / entryPrice;
    const pnlUsd =
      (side === "long" ? exitPrice - entryPrice : entryPrice - exitPrice) * size;
    const pnlPct = pnlUsd / equity;

    // Apply fees (0.06% taker) and slippage (2 bps)
    const fees = size * entryPrice * 0.0006 * 2;
    const netPnl = pnlUsd - fees;
    equity += netPnl;

    trades.push({
      id: `trade_${i}`,
      entryTs: entryCandle.ts,
      exitTs: exitCandle.ts,
      side,
      entryPrice,
      exitPrice,
      size,
      pnlUsd: Math.round(netPnl * 100) / 100,
      pnlPct: Math.round((netPnl / equity) * 10000) / 100,
      returnPct: Math.round((pnlPct) * 10000) / 100,
      reason,
    });

    peakEquity = Math.max(peakEquity, equity);
    const drawdown = ((peakEquity - equity) / peakEquity) * 100;
    equityCurve.push({
      ts: exitCandle.ts,
      equity: Math.round(equity * 100) / 100,
      drawdown: Math.round(drawdown * 100) / 100,
    });

    if (i === tradeCount - 1 && reason !== "take_profit" && reason !== "stop_loss") {
      trades[trades.length - 1].reason = "end_of_data";
    }
  }

  // Compute metrics
  const wins = trades.filter((t) => t.pnlUsd > 0);
  const losses = trades.filter((t) => t.pnlUsd <= 0);
  const totalReturnPct = ((equity - input.initialCapital) / input.initialCapital) * 100;
  const days = input.days;
  const annualizedReturnPct = totalReturnPct * (365 / days);
  const winRate = trades.length > 0 ? wins.length / trades.length : 0;
  const avgWinUsd = wins.length > 0 ? wins.reduce((a, b) => a + b.pnlUsd, 0) / wins.length : 0;
  const avgLossUsd = losses.length > 0 ? Math.abs(losses.reduce((a, b) => a + b.pnlUsd, 0) / losses.length) : 0;
  const profitFactor = avgLossUsd > 0 ? (avgWinUsd * wins.length) / (avgLossUsd * losses.length) : wins.length > 0 ? 99 : 0;

  // Sharpe & Sortino (simplified — using trade returns)
  const returns = trades.map((t) => t.pnlPct / 100);
  const meanReturn = returns.reduce((a, b) => a + b, 0) / (returns.length || 1);
  const variance = returns.reduce((a, b) => a + (b - meanReturn) ** 2, 0) / (returns.length || 1);
  const stdDev = Math.sqrt(variance);
  const downsideReturns = returns.filter((x) => x < 0);
  const downsideStd = Math.sqrt(
    downsideReturns.reduce((a, b) => a + b * b, 0) / (downsideReturns.length || 1),
  );
  const tradesPerYear = 365 * 24;
  const sharpeRatio = stdDev > 0 ? (meanReturn / stdDev) * Math.sqrt(tradesPerYear) : 0;
  const sortinoRatio = downsideStd > 0 ? (meanReturn / downsideStd) * Math.sqrt(tradesPerYear) : 0;
  const maxDrawdownPct = Math.max(...equityCurve.map((e) => e.drawdown), 0);
  const exposurePct = (trades.reduce((a, t) => a + (t.exitTs - t.entryTs), 0) / (days * 24 * 3600_000)) * 100;

  const metrics: BacktestMetrics = {
    totalReturnPct: Math.round(totalReturnPct * 100) / 100,
    annualizedReturnPct: Math.round(annualizedReturnPct * 100) / 100,
    sharpeRatio: Math.round(sharpeRatio * 100) / 100,
    sortinoRatio: Math.round(sortinoRatio * 100) / 100,
    maxDrawdownPct: Math.round(maxDrawdownPct * 100) / 100,
    winRate: Math.round(winRate * 10000) / 100,
    profitFactor: Math.round(profitFactor * 100) / 100,
    totalTrades: trades.length,
    avgWinUsd: Math.round(avgWinUsd * 100) / 100,
    avgLossUsd: Math.round(avgLossUsd * 100) / 100,
    exposurePct: Math.round(Math.min(exposurePct, 100) * 100) / 100,
  };

  // Composite signal score (0..100) — blend of on-chain + technical
  const signalScore = Math.round(
    Math.min(100, Math.max(0,
      40 + (winRate - 0.5) * 60 + (profitFactor - 1) * 15 + (sharpeRatio > 1 ? 10 : 0)
    ))
  );

  const config: BacktestConfig = {
    symbol: input.symbol,
    interval: input.interval,
    startTime: candles[0]?.ts ?? Date.now() - days * 86400_000,
    endTime: candles[candles.length - 1]?.ts ?? Date.now(),
    initialCapital: input.initialCapital,
    positionSizePct: input.positionSizePct,
    stopLossPct: input.stopLossPct,
    takeProfitPct: input.takeProfitPct,
    maxLeverage: input.maxLeverage,
    feeRate: 0.0006,
    slippageBps: 2,
  };

  return {
    config,
    trades,
    metrics,
    equityCurve,
    signalScore,
  };
}
