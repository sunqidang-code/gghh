"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface SdkSettings {
  apiKey: string;
  apiSecret: string;
  passphrase: string;
  playbookKey: string;
  baseUrl: string;
  productType: "SPOT" | "USDT-FUTURES" | "COIN-FUTURES";
  telemetry: boolean;
  defaultLeverage: number;
  maxExposureUsd: number;
  alertThresholds: {
    whaleMinUsd: number;
    fundingRateMax: number;
    oiChangePct: number;
    volumeSpikeX: number;
  };
}

interface AppState {
  settings: SdkSettings;
  updateSettings: (partial: Partial<SdkSettings>) => void;
  resetSettings: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const DEFAULT_SETTINGS: SdkSettings = {
  apiKey: "",
  apiSecret: "",
  passphrase: "",
  playbookKey: "",
  baseUrl: "https://api.bitget.com",
  productType: "USDT-FUTURES",
  telemetry: false,
  defaultLeverage: 5,
  maxExposureUsd: 100_000,
  alertThresholds: {
    whaleMinUsd: 500_000,
    fundingRateMax: 0.05,
    oiChangePct: 15,
    volumeSpikeX: 2.5,
  },
};

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      settings: DEFAULT_SETTINGS,
      updateSettings: (partial) =>
        set((state) => ({
          settings: {
            ...state.settings,
            ...partial,
            alertThresholds: {
              ...state.settings.alertThresholds,
              ...(partial.alertThresholds ?? {}),
            },
          },
        })),
      resetSettings: () => set({ settings: DEFAULT_SETTINGS }),
      activeTab: "dashboard",
      setActiveTab: (tab) => set({ activeTab: tab }),
      sidebarOpen: false,
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
    }),
    {
      name: "bitget-onchain-agent-store",
      partialize: (state) => ({ settings: state.settings }),
    },
  ),
);
